#!/usr/bin/env python3
"""Отчёт по качеству перевода: метрики, распределение нарушений, примеры.

Пример:
    python3 scripts/05_report.py --input results/oasst1_en_full.tp.jsonl
"""

from __future__ import annotations

import argparse
import collections
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tp_translate.en_lexicon import EnLexicon  # noqa: E402
from tp_translate.evaluate import evaluate  # noqa: E402
from tp_translate.grammar import TokiPonaValidator  # noqa: E402
from tp_translate.lexicon import Lexicon  # noqa: E402
from tp_translate.pipeline import TranslationRecord  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]


def load_records(path: Path) -> list[TranslationRecord]:
    records: list[TranslationRecord] = []
    with open(path, "rt", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            data = json.loads(line)
            records.append(
                TranslationRecord(
                    message_id=data["message_id"],
                    role=data.get("role", ""),
                    lang=data.get("lang", ""),
                    text_en=data.get("text_en", ""),
                    text_tp=data.get("text_toki_pona", ""),
                    violations=data.get("violations", []),
                    stats=data.get("stats", {}),
                )
            )
    return records


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--out", default=None)
    ap.add_argument("--examples", type=int, default=8)
    args = ap.parse_args()

    tp_lex = Lexicon.from_json(ROOT / "refs" / "lexicon.json")
    validator = TokiPonaValidator(tp_lex)

    records = load_records(Path(args.input))
    # nimi tawa, встреченные при переводе, считаем допустимыми словами
    loans: set[str] = set()
    for rec in records:
        loans.update(rec.stats.get("loan_words", []))
    validator.known_loans.update(loans)

    metrics = evaluate(records, validator)
    metrics["loans_total"] = len(loans)

    print("=" * 66)
    print("МЕТРИКИ ПЕРЕВОДА НА ТОКИ ПОНА")
    print("=" * 66)
    print(f"сообщений:                {metrics['messages']}")
    print(f"предложений:              {metrics['sentences']}")
    print(f"слов EN / TP:             {metrics['words_en']} / {metrics['words_tp']}"
          f"  (отношение {metrics['length_ratio']})")
    print(f"покрытие словаря:         {metrics['lexicon_coverage_pct']}%")
    print(f"предложений без ошибок:   {metrics['sentences_clean_pct']}%")
    print(f"сообщений без ошибок:     {metrics['messages_clean_pct']}%")
    print(f"уникальных nimi tawa:     {metrics['loans_total']}")
    print()
    print("нарушения по правилам (все):")
    for rule, cnt in metrics["violations_by_rule"].items():
        print(f"  {rule:<18} {cnt}")
    print()
    print("ошибки по правилам:")
    for rule, cnt in metrics["errors_by_rule"].items():
        print(f"  {rule:<18} {cnt}")

    # самые частые неизвестные слова — кандидаты в словарь
    top = metrics["top_unknown_tokens"][:25]
    if top:
        print()
        print("частые неизвестные слова (в словарь):")
        for word, cnt in top:
            print(f"  {word:<18} {cnt}")

    # примеры перевода
    print()
    print("=" * 66)
    print("ПРИМЕРЫ (первые подходящие)")
    print("=" * 66)
    shown = 0
    for rec in records:
        if len(rec.text_en) < 80 or len(rec.text_en) > 600:
            continue
        if shown >= args.examples:
            break
        shown += 1
        print(f"\nEN: {rec.text_en[:400]}")
        print(f"TP: {rec.text_tp[:400]}")
        if rec.violations:
            bad = [v for v in rec.violations if v["severity"] == "error"][:3]
            for v in bad:
                print(f"   ! {v['rule']}: {v['message']}")

    if args.out:
        out = Path(args.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(metrics, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"\nметрики сохранены: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
