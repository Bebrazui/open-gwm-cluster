#!/usr/bin/env python3
"""Золотой тест: примеры из lipu pu как эталон качества переводчика.

В книге «Toki Pona: The Language of Good» (jan Sonja Lang) к каждому уроку
идут примеры с переводом: сначала фраза на токи пона, затем её английский
перевод. Эти пары — готовый эталон: сравниваем перевод нашего транслятора
с книжным и считаем BLEU-4 и точное совпадение.

Запуск:  python3 scripts/07_book_examples.py
"""

from __future__ import annotations

import math
import re
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tp_translate.en_lexicon import EnLexicon  # noqa: E402
from tp_translate.lexicon import Lexicon  # noqa: E402
from tp_translate.translator import Translator  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]


def extract_pairs(pdf_path: Path) -> list[tuple[str, str]]:
    """Достать пары (токи пона, английский) из раздела Examples."""
    from pypdf import PdfReader

    reader = PdfReader(str(pdf_path))
    text = "\n".join((p.extract_text() or "") for p in reader.pages)
    lines = [l.replace("\xa0", " ").strip() for l in text.split("\n")]

    stop = {
        "Translate", "Answers", "Story", "Practise", "Go to answers.",
        "Read these words aloud.", "Examples", "Back to Lesson",
    }
    pairs: list[tuple[str, str]] = []
    inside = False
    for i, line in enumerate(lines):
        if line == "Examples":
            inside = True
            continue
        if inside and (line in stop or line.startswith("Lesson ") or line.startswith("<<<PAGE")):
            inside = False
            continue
        if not inside:
            continue
        m = re.match(r"^(\d+)\.\s+(.+)$", line)
        if not m:
            continue
        tp = m.group(2).strip()
        if tp.endswith("."):
            tp = tp[:-1]
        if not re.fullmatch(r"[a-z' ]+", tp) or len(tp.split()) < 2:
            continue
        # следующая непустая строка — английский перевод
        for nxt in lines[i + 1 : i + 4]:
            if not nxt:
                continue
            if re.match(r"^\d+\.\s", nxt) or nxt in stop:
                break
            if re.search(r"[A-Z]", nxt) and len(nxt.split()) >= 2:
                pairs.append((tp, nxt))
            break
    return pairs


def bleu(candidate: str, reference: str, max_n: int = 4) -> float:
    """BLEU с сглаживанием (близко к sacrebleu для коротких предложений)."""
    c = candidate.lower().split()
    r = reference.lower().split()
    if not c or not r:
        return 0.0
    precisions = []
    for n in range(1, max_n + 1):
        cn = Counter(tuple(c[i : i + n]) for i in range(len(c) - n + 1))
        rn = Counter(tuple(r[i : i + n]) for i in range(len(r) - n + 1))
        overlap = sum(min(cn[k], rn[k]) for k in cn)
        total = max(sum(cn.values()), 1)
        precisions.append(overlap / total)
    if min(precisions) == 0:
        precisions = [1e-9 if p == 0 else p for p in precisions]
    log_avg = sum(math.log(p) for p in precisions) / len(precisions)
    brevity = 1.0 if len(c) > len(r) else math.exp(1 - len(r) / max(len(c), 1))
    return 100 * brevity * math.exp(log_avg)


def main() -> int:
    pdf = ROOT / "refs" / "lipu_pu2.pdf"
    pairs = extract_pairs(pdf)
    print(f"пар из книги: {len(pairs)}")

    tp_lex = Lexicon.from_json(ROOT / "refs" / "lexicon.json")
    en_lex = EnLexicon.from_json(ROOT / "data" / "en_tp_lexicon.json")
    translator = Translator(tp_lex, en_lex)

    exact = 0
    scores: list[float] = []
    show = int(sys.argv[1]) if len(sys.argv) > 1 else 12
    shown = 0
    print()
    print(f"{'BOOK (toki pona)':<44} | OUR TRANSLATION")
    print("-" * 110)
    for ref_tp, ref_en in pairs:
        out, _ = translator.translate(ref_en)
        score = bleu(out, ref_tp)
        scores.append(score)
        if out.strip().rstrip(".") == ref_tp.strip().rstrip("."):
            exact += 1
        if shown < show:
            print(f"{ref_tp[:43]:<44} | {out[:60]}")
            shown += 1

    mean = sum(scores) / len(scores) if scores else 0.0
    print("-" * 110)
    print(f"BLEU-4 (среднее по {len(scores)} примерам): {mean:.2f}")
    print(f"точное совпадение с книгой: {exact}/{len(pairs)} ({100 * exact / max(len(pairs), 1):.1f}%)")
    print(f"совпадение по BLEU >= 20: {sum(1 for s in scores if s >= 20)}/{len(scores)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
