#!/usr/bin/env python3
"""Скачать исходные данные: датасет OASST1 и справочные материалы по токи пона.

Запуск:  python3 scripts/01_fetch_sources.py [--skip-dataset]
"""

from __future__ import annotations

import argparse
import sys
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
REFS = ROOT / "refs"

DATASET_FILES = [
    "2023-04-12_oasst_ready.messages.jsonl.gz",
    "2023-04-12_oasst_ready.trees.jsonl.gz",
    "2023-04-12_oasst_all.messages.jsonl.gz",
]
DATASET_BASE = "https://huggingface.co/datasets/OpenAssistant/oasst1/resolve/main"

REF_FILES = [
    (
        "lipu_pu2.pdf",
        "https://upload.wikimedia.org/wikipedia/commons/4/40/Toki_Pona_The_Language_of_Good.pdf",
        "официальная книга «Toki Pona: The Language of Good» (словарь + грамматика)",
    ),
    (
        "janne_dict.html",
        "https://jan-ne.github.io/tp/dictionary",
        "официальный словарь токи пона (lipu pi jan Ne)",
    ),
]


def download(url: str, dest: Path, min_bytes: int = 1000) -> bool:
    if dest.exists() and dest.stat().st_size > min_bytes:
        print(f"  уже есть: {dest.name} ({dest.stat().st_size // 1024} КБ)")
        return True
    dest.parent.mkdir(parents=True, exist_ok=True)
    print(f"  скачиваю {dest.name} ...", end=" ", flush=True)
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=120) as resp, open(dest, "wb") as fh:
            fh.write(resp.read())
    except Exception as exc:  # noqa: BLE001
        print(f"ОШИБКА: {exc}")
        return False
    size = dest.stat().st_size
    if size < min_bytes:
        print(f"ОШИБКА: слишком мал ({size} байт)")
        return False
    print(f"ок, {size // 1024} КБ")
    return True


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--skip-dataset", action="store_true")
    args = ap.parse_args()

    print("Материалы по токи пона:")
    for name, url, desc in REF_FILES:
        print(f"  {desc}")
        download(url, REFS / name)
        if not (REFS / name).exists():
            print(f"  ВНИМАНИЕ: не удалось получить {name}", file=sys.stderr)

    if not args.skip_dataset:
        print("Датасет OpenAssistant OASST1:")
        for name in DATASET_FILES:
            download(f"{DATASET_BASE}/{name}", DATA / name, min_bytes=100_000)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
