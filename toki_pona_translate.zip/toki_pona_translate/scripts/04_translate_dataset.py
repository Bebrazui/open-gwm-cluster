#!/usr/bin/env python3
"""Перевести датасет на токи пона и проверить грамматику результата.

Примеры:
    python3 scripts/04_translate_dataset.py --dataset oasst1 --lang en
    python3 scripts/04_translate_dataset.py --dataset oasst1 --limit 500 --tag test
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tp_translate.corpora import build_corpus  # noqa: E402
from tp_translate.en_lexicon import EnLexicon  # noqa: E402
from tp_translate.grammar import TokiPonaValidator  # noqa: E402
from tp_translate.lexicon import Lexicon  # noqa: E402
from tp_translate.pipeline import TranslationPipeline  # noqa: E402
from tp_translate.translator import Translator  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default="oasst1")
    ap.add_argument("--path", default=None, help="путь к корпусу (для произвольных jsonl)")
    ap.add_argument("--lang", default="en")
    ap.add_argument("--limit", type=int, default=None)
    ap.add_argument("--tag", default="full", help="подпись прогона (имя выходных файлов)")
    ap.add_argument("--out-dir", default=str(ROOT / "results"))
    ap.add_argument("--no-validate", action="store_true")
    args = ap.parse_args()

    tp_lex = Lexicon.from_json(ROOT / "refs" / "lexicon.json")
    en_lex = EnLexicon.from_json(ROOT / "data" / "en_tp_lexicon.json")
    translator = Translator(tp_lex, en_lex)
    validator = TokiPonaValidator(tp_lex)

    corpus_kwargs = {"filter_lang": args.lang, "limit": args.limit}
    if args.path:
        from tp_translate.corpora import JsonlCorpus

        corpus = JsonlCorpus(path=args.path, **corpus_kwargs)
    else:
        corpus = build_corpus(args.dataset, **corpus_kwargs)

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    cache_path = out_dir / f"{args.dataset}_{args.lang}_{args.tag}.cache.jsonl"
    out_path = out_dir / f"{args.dataset}_{args.lang}_{args.tag}.tp.jsonl"

    version = hashlib.sha256(
        (ROOT / "refs" / "lexicon.json").read_bytes()
        + (ROOT / "data" / "en_tp_lexicon.json").read_bytes()
    ).hexdigest()[:12]

    pipeline = TranslationPipeline(
        translator,
        validator=validator,
        cache_path=cache_path,
        validate=not args.no_validate,
        version=version,
    )
    print(f"версия словарей: {version}")

    started = time.time()
    count = 0
    errors = 0

    def progress(done: int, elapsed: float) -> None:
        rate = done / elapsed if elapsed else 0
        print(
            f"  переведено {done} сообщений за {elapsed:.1f}с "
            f"({rate:.0f} сообщений/с)",
            flush=True,
        )

    with open(out_path, "wt", encoding="utf-8") as fh:
        for record in pipeline.run(corpus, limit=args.limit, progress_every=5000, on_progress=progress):
            fh.write(json.dumps(record.to_json(), ensure_ascii=False) + "\n")
            count += 1
            errors += record.stats.get("errors", 0)

    elapsed = time.time() - started
    print(
        f"готово: {count} сообщений за {elapsed:.1f}с; "
        f"нарушений грамматики (error): {errors}\n"
        f"кэш: {cache_path}\n"
        f"перевод: {out_path}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
