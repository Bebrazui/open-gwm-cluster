#!/usr/bin/env python3
"""Собрать data/en_tp_lexicon.json: английский -> токи пона.

Источники:
  * data/curated_en_tp.json — кураторская таблица (приоритет);
  * refs/lexicon.json — глоссы официальных словарей токи пона, из которых
    автоматически выравниваются кандидаты (глосс вида "good, nice, clean"
    даёт good->pona, nice->pona, clean->pona).

Запуск:  python3 scripts/03_build_en_lexicon.py
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tp_translate.en_lexicon import (  # noqa: E402
    TP_ADJ,
    TP_ADV,
    TP_NOUN,
    TP_NUMBER,
    TP_PARTICLE,
    TP_PREVERB,
    TP_VERB,
    EnEntry,
    EnLexicon,
)

ROOT = Path(__file__).resolve().parents[1]

STOPWORDS = {
    "to", "be", "is", "are", "was", "were", "been", "being", "a", "an", "the",
    "and", "or", "of", "with", "in", "for", "from", "as", "by", "like", "at",
    "on", "that", "this", "it", "its", "one", "other", "than", "then", "so",
    "there", "here", "when", "what", "which", "who", "whom", "how", "why",
    "into", "onto", "over", "under", "about", "some", "any", "each", "every",
    "more", "most", "very", "much", "many", "not", "no", "yes", "do", "does",
    "did", "have", "has", "had", "can", "could", "may", "might", "must",
    "should", "would", "will", "shall", "up", "down", "out", "off", "again",
    "also", "just", "only", "even", "still", "too", "such", "own", "same",
    "if", "but", "or", "because", "while", "during", "until", "between",
}

TP_POS_FROM_LEX = {
    "NOUN": (TP_NOUN, "NOUN"),
    "VERB": (TP_VERB, "VERB"),
    "ADJECTIVE": (TP_ADJ, "ADJ"),
    "PRE-VERB": (TP_PREVERB, "VERB"),
    "PREPOSITION": (None, "PREP"),
    "PARTICLE": (TP_PARTICLE, "ADV"),
    "NUMBER": (TP_NUMBER, "NUM"),
    "ADVERB": (TP_ADV, "ADV"),
    "INTERJECTION": (TP_ADV, "INTERJ"),
}


def gloss_candidates(gloss: str) -> list[str]:
    """Кандидаты английских заголовков из глосса."""
    out: list[str] = []
    text = re.sub(r"\([^)]*\)", " ", gloss)
    for chunk in re.split(r"[;,\.]", text):
        chunk = chunk.strip().lower()
        if not chunk:
            continue
        chunk = re.sub(r"^(to|being)\s+", "", chunk)
        words = re.findall(r"[a-z]+", chunk)
        if not words:
            continue
        head = words[0]
        if head in STOPWORDS or len(head) < 2:
            continue
        if head not in out:
            out.append(head)
    return out


def main() -> int:
    tp_lex = json.loads((ROOT / "refs" / "lexicon.json").read_text(encoding="utf-8"))
    curated_raw = json.loads(
        (ROOT / "data" / "curated_en_tp.json").read_text(encoding="utf-8")
    )

    entries: dict[str, EnEntry] = {}
    stats = {"auto": 0, "conflicts": 0}

    # 1) автоматическое выравнивание по глоссам
    for word, data in tp_lex["words"].items():
        gloss = data.get("gloss", "")
        if not gloss:
            continue
        for pos in data.get("pos", []):
            mapping = TP_POS_FROM_LEX.get(pos)
            if mapping is None:
                continue
            tp_pos, en_pos = mapping
            if tp_pos in (None, TP_PARTICLE):
                continue
            for cand in gloss_candidates(gloss):
                if cand in entries:
                    stats["conflicts"] += 1
                    continue
                entries[cand] = EnEntry(
                    lemma=cand,
                    tp=[word],
                    tp_pos=tp_pos,
                    en_pos=en_pos,
                    source="gloss",
                )
                stats["auto"] += 1

    # 2) кураторская таблица перекрывает автоматику
    for lemma, e in curated_raw["entries"].items():
        tp = e.get("tp")
        if tp is None:
            tp_words: list[str] = []
        elif isinstance(tp, str):
            tp_words = tp.split()
        else:
            tp_words = list(tp)
        entries[lemma] = EnEntry(
            lemma=lemma,
            tp=tp_words,
            tp_pos=e.get("tp_pos"),
            en_pos=e.get("en_pos", "NOUN"),
            tags=set(e.get("tags", [])),
            source="curated",
        )

    phrases = {k: list(v) for k, v in curated_raw.get("phrases", {}).items()}
    clause_phrases = set(curated_raw.get("clause_phrases", []))

    lex = EnLexicon(entries, phrases, clause_phrases)
    out_path = ROOT / "data" / "en_tp_lexicon.json"
    lex.save(out_path)

    print(f"автоматических записей: {stats['auto']} (конфликтов глоссов: {stats['conflicts']})")
    print(f"всего в словаре: {len(entries)} (из них кураторских: {sum(1 for e in entries.values() if e.source == 'curated')})")
    print(f"фразовых шаблонов: {len(phrases)} (из них конструкций: {len(clause_phrases)})")
    print(f"записано: {out_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
