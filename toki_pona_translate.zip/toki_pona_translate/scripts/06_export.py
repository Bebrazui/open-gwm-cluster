#!/usr/bin/env python3
"""Экспорт переведённого датасета в готовые файлы.

Пример:
    python3 scripts/06_export.py --input results/oasst1_en_full.tp.jsonl \
        --prefix results/oasst1_en_full
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tp_translate.export import export_hf_style, export_jsonl, export_summary  # noqa: E402
from tp_translate.pipeline import TranslationRecord  # noqa: E402


def load_records(path: Path) -> list[TranslationRecord]:
    records: list[TranslationRecord] = []
    with open(path, "rt", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            data = json.loads(line)
            records.append(
                TranslationRecord(
                    message_id=data["message_id"],
                    role=data.get("role", ""),
                    lang=data.get("lang", ""),
                    text_en=data.get("text_en", ""),
                    text_tp=data.get("text_toki_pona", ""),
                    violations=data.get("violations", []),
                    stats=data.get("stats", {}),
                    version=data.get("version", ""),
                )
            )
    return records


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--prefix", default=None, help="префикс выходных файлов")
    ap.add_argument("--metrics", default=None, help="файл с метриками (копируется как .metrics.json)")
    args = ap.parse_args()

    src = Path(args.input)
    prefix = Path(args.prefix) if args.prefix else src.with_suffix("")
    records = load_records(src)

    full = Path(str(prefix) + ".jsonl")
    hf = Path(str(prefix) + ".hf.jsonl")
    n1 = export_jsonl(records, full)
    n2 = export_hf_style(records, hf)

    if args.metrics and Path(args.metrics).exists():
        export_summary(json.loads(Path(args.metrics).read_text(encoding="utf-8")),
                       Path(str(prefix) + ".metrics.json"))

    print(f"сообщений: {n1}")
    print(f"полный формат (en + toki pona + проверки): {full}")
    print(f"формат в стиле OpenAssistant/oasst1: {hf}")
    print(
        "\nЗагрузка в datasets:\n"
        "  from datasets import Dataset\n"
        f"  ds = Dataset.from_json('{hf}')\n"
        "  # поле text_toki_pona содержит перевод на токи пона"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
