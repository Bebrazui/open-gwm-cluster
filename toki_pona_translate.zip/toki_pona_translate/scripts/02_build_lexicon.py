#!/usr/bin/env python3
"""Собрать refs/lexicon.json из официальных словарей токи пона.

Источники:
  * nimi pu — PDF "Toki Pona: The Language of Good" (refs/lipu_pu2.pdf);
  * nimi ku — Toki Pona Dictionary (refs/janne_dict.html).

Запуск:  python3 scripts/02_build_lexicon.py
"""

from __future__ import annotations

import html
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tp_translate.lexicon import ALL_POS, Entry, Lexicon  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
REFS = ROOT / "refs"

#: nimi ku suli — 17 слов, добавленных в «Toki Pona Dictionary» (2021).
#: Источник: статья «nimi ku» вики sona.pona.la со ссылкой на опрос
#: сообщества ma pona pi toki pona.
KU_SULI: dict[str, tuple[str, str]] = {
    "namako": ("NOUN", "spice, addition; additional, extra"),
    "kin": ("PARTICLE", "or (emphasis, emotion or confirmation)"),
    "oko": ("NOUN", "eye"),
    "kipisi": ("NOUN", "piece, fragment, part"),
    "leko": ("NOUN", "edge, rim, border"),
    "monsuta": ("NOUN", "crop, sprout, harvest"),
    "tonsi": ("NOUN", "ten, ten thousand"),
    "jasima": ("NOUN", "jasmine"),
    "kijetesantakalu": ("NOUN", "chicken (the logo of the chicken-queen movement)"),
    "soko": ("ADJECTIVE", "reversed, inverted, backwards"),
    "meso": ("ADJECTIVE", "mesopotamian, from Mesopotamia"),
    "epiku": ("ADJECTIVE", "epic"),
    "kokosila": ("NOUN", "coconut, cocoyam"),
    "lanpan": ("ADJECTIVE", "bland, dull, uninteresting"),
    "n": ("INTERJECTION", "onomatopoeia of a broken voice"),
    "misikeke": ("NOUN", "mischief, prank"),
}

POS_PREFIXES = sorted(ALL_POS, key=len, reverse=True)


# --------------------------------------------------------------------------
# nimi pu: PDF со словарём
# --------------------------------------------------------------------------
def parse_pdf_dictionary(pdf_path: Path) -> tuple[dict[str, Entry], dict[str, str]]:
    from pypdf import PdfReader

    reader = PdfReader(str(pdf_path))
    # ищем страницы со словарём: заголовок "Official Toki Pona Dictionary"
    pages: list[str] = []
    started = False
    for page in reader.pages:
        text = page.extract_text() or ""
        if "Toki Pona Dictionary" in text:
            started = True
        if started:
            pages.append(text)
    raw = "\n".join(pages)
    lines = [l.replace("\xa0", " ").strip() for l in raw.split("\n")]
    lines = [l for l in lines if l]

    entries: dict[str, Entry] = {}
    aliases: dict[str, str] = {}
    current: Entry | None = None

    def is_pos_line(line: str) -> bool:
        return any(line.startswith(p + " ") or line == p for p in POS_PREFIXES)

    def new_entry(head: str) -> Entry:
        nonlocal current
        words = [w.strip() for w in head.split(" or ")]
        main = words[0]
        current = Entry(word=main, sources={"pu"})
        entries[main] = current
        for alias in words[1:]:
            aliases[alias] = main
        return current

    # заголовок — слово, если (а) выглядит как слово, (б) за ним идёт строка
    # части речи (возможно через "or" + синоним), (в) словарь упорядочен
    # алфавитно, поэтому заголовок не может идти раньше предыдущего.
    prev_head = ""
    for idx, line in enumerate(lines):
        if "Toki Pona Dictionary" in line:
            continue
        pos = next((p for p in POS_PREFIXES if line.startswith(p + " ")), None)
        if pos:
            rest = line[len(pos):].strip()
            if current is not None:
                current.pos.add(pos)
                if rest:
                    current.gloss = (current.gloss + "; " + rest).strip("; ")
            continue
        if re.fullmatch(r"[a-z]+(?: or [a-z]+)?", line):
            nxt = lines[idx + 1] if idx + 1 < len(lines) else ""
            nxt2 = lines[idx + 2] if idx + 2 < len(lines) else ""
            head_ok = is_pos_line(nxt) or (nxt == "or" and is_pos_line(nxt2))
            alpha_ok = (not prev_head) or line.split(" or ")[0] >= prev_head
            if head_ok and alpha_ok:
                new_entry(line)
                prev_head = line.split(" or ")[0]
                continue
        if current is not None and line:
            current.gloss = (current.gloss + " " + line).strip()
    return entries, aliases


# --------------------------------------------------------------------------
# nimi ku: HTML-версия словаря
# --------------------------------------------------------------------------
def parse_html_dictionary(html_path: Path) -> tuple[dict[str, Entry], dict[str, str]]:
    raw = html_path.read_text(encoding="utf-8", errors="replace")
    raw = re.sub(r"(?s)<(script|style).*?</\1>", " ", raw)
    text = re.sub(r"(?s)<[^>]+>", "\n", raw)
    text = html.unescape(text)
    lines = [l.strip() for l in text.split("\n")]
    lines = [l for l in lines if l]

    def is_pos(line: str) -> bool:
        return any(line.startswith(p + " ") or line == p for p in POS_PREFIXES)

    def is_word(line: str) -> bool:
        return bool(re.fullmatch(r"[a-z]+", line))

    entries: dict[str, Entry] = {}
    aliases: dict[str, str] = {}
    current: Entry | None = None
    prev_head = ""
    i = 0
    while i < len(lines):
        line = lines[i]
        # заголовки сайта — пропускаем
        if line in {"Official Dictionary", "Etymology", "Other Words", "Phonetic Guidelines"}:
            i += 1
            continue
        if is_pos(line):
            if current is not None:
                p = next(p for p in POS_PREFIXES if line.startswith(p + " ") or line == p)
                rest = line[len(p):].strip()
                current.pos.add(p)
                if rest:
                    current.gloss = (current.gloss + "; " + rest).strip("; ")
            i += 1
            continue
        if is_word(line):
            # слово-заголовок: за ним либо POS, либо "or" + синоним;
            # словарь упорядочен алфавитно — это отсекает слова из глосс
            nxt = lines[i + 1] if i + 1 < len(lines) else ""
            nxt2 = lines[i + 2] if i + 2 < len(lines) else ""
            head_ok = is_pos(nxt) or (nxt == "or" and is_word(nxt2))
            alpha_ok = (not prev_head) or line >= prev_head
            if head_ok and alpha_ok:
                current = Entry(word=line, sources={"ku"})
                entries[line] = current
                prev_head = line
                if nxt == "or" and is_word(nxt2):
                    aliases[nxt2] = line
                    i += 2
                i += 1
                continue
        if current is not None:
            current.gloss = (current.gloss + " " + line).strip()
        i += 1
    return entries, aliases


def main() -> int:
    pdf = REFS / "lipu_pu2.pdf"
    htm = REFS / "janne_dict.html"
    if not pdf.exists() or not htm.exists():
        print("Нужны refs/lipu_pu2.pdf и refs/janne_dict.html — запусти scripts/01_fetch_sources.py", file=sys.stderr)
        return 1

    pu, pu_alias = parse_pdf_dictionary(pdf)
    ku, ku_alias = parse_html_dictionary(htm)
    print(f"nimi pu: {len(pu)} слов, {len(pu_alias)} синонимов")
    print(f"nimi ku: {len(ku)} слов, {len(ku_alias)} синонимов")

    merged: dict[str, Entry] = {}
    aliases: dict[str, str] = {}
    for source, table in (("pu", pu), ("ku", ku)):
        for word, entry in table.items():
            if word in merged:
                tgt = merged[word]
                tgt.pos |= entry.pos
                if entry.gloss and entry.gloss not in tgt.gloss:
                    tgt.gloss = (tgt.gloss + "; " + entry.gloss).strip("; ")
                tgt.sources |= {source}
            else:
                merged[word] = Entry(
                    word=word, pos=set(entry.pos), gloss=entry.gloss, sources={source}
                )
    for source, table in (("pu", pu_alias), ("ku", ku_alias)):
        for alias, main in table.items():
            aliases.setdefault(alias, main)

    # nimi ku suli — слова из словаря 2021 года
    for word, (pos, gloss) in KU_SULI.items():
        if word in merged:
            merged[word].pos.add(pos)
            merged[word].sources.add("ku")
            if gloss and gloss not in merged[word].gloss:
                merged[word].gloss = f"{merged[word].gloss}; {gloss}".strip("; ")
        else:
            merged[word] = Entry(word=word, pos={pos}, gloss=gloss, sources={"ku"})

    lex = Lexicon(merged, aliases)
    out = REFS / "lexicon.json"
    lex.save(out)

    from tp_translate.phonology import check_word

    bad = [(w, check_word(w)) for w in lex.words if check_word(w)]
    print(f"всего слов в лексиконе: {len(lex)}  (алиасы: {len(aliases)})")
    print(f"слов с нарушениями фонетики: {len(bad)}")
    for w, errs in bad[:15]:
        print("  !", w, errs)
    print(f"записано: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
