# Примеры перевода OASST1: английский -> токи пона

Файлы: `results/oasst1_en_full.hf.jsonl` (формат как у OpenAssistant/oasst1) и
`results/oasst1_en_full.jsonl` (полный: оригинал, перевод, нарушения грамматики).

Ниже — сообщения, которые прошли валидатор грамматики lipu pu без ошибок.

| # | English | toki pona |
|---|---|---|
| 1 | Provide a few lightbox product recommendations as I am currently interested in buying one for art. | o pana e itelete pi lekometasino tenpo ni ilo liko mute lili wan sama mi tawa sitelen. |
| 2 | Wow okay. I just wanted some tips for finding out if someone was interested in me. | o pona. mi lon li wile pali e itelete pi jan si lon mi weka. |
| 3 | How many possible board combinations are there on a regular chessboard? Please show the step by step process to end up at the solution. | mute kopinasimo pi poa ken li lon kesoa pi lekula lon sewi? o pana e pali pi pali lon ni pona sewi. |
| 4 | Thank you. Could you change the program that it only prints the size without text? | pona. sina ken ante e suli pi ona lipu toki ni taso kepeken ala nimi anu seme? |
| 5 | Why does Roblox have an advantage over other similar companies making metaverse and games? | lolo li pali e musi pi metawese awataken lon sewi kulupu sama ante tan seme? |
| 6 | can I use a decorator within a code? as part of a function instead of outside of it? | mi ken kepeken tekolato lon lipu toki anu seme? |
| 7 | Can you describe the outfit of the characters in the scene? Given that they are weird yet iconic. | sina ken toki e oupi pi nimi lon kene anu seme? o pana e ikoni pi je wei ona ni. |
| 8 | Imagine a world in which electricity was never made use of on the scale it is currently, but modern inventions that typically use electricity still exist in another form.  Please describe how some of these inventions may work. | ma pi imakine.  o toki pi iwesino ni li'u. |
| 9 | Perfect, now do the following:   - Clean up the formatting so  the lines are properly capitalized   - Convert this to a YAML file where each item is a `todo` that has the following properties: message, dateAdded, dueBy (date, opti | pepe tenpo ni li pali e ni kama. - o kama pona pali e kapitalise pi linja pona pomasi sewi. - kowe ni.`todo`ni li pali e tatu pi osipona tate tue tateate lipu toki lopesile ni kama. |
| 10 | Good to know. What does the symbol of a triangle with an eye in the middle mean? | pona. seme sitelen li pali pi litane kepeken oko lon mite? |
| 11 | Write a alternative history for Messy in which he doesn't need hormone teraphy. Would he be better than Christiano Ronaldino? | o sitelen e tela pi omone lipu pini atenasiwe tawa me lon ona pi seme ala. ona li wile lonasino pi lisisano pona mute anu seme? |
| 12 | That is great suggestions. However, looking at your suggestion, I found that it is quite weird that you suggest this to be more futuristic where Link character is more, like, medieval era. This might be a good choice for Cyberpunk | ni li sukesiso pona suli. taso li lukin e ela pi mesiewa nimi li putulisi sina ni wei ni ona ni lon seme lon mi pi sukesison sina mute. ni li ken mi pi poka pona tawa kepu tawa li ni kepeken li ala. |
| 13 | Here is a short melody: E-G-A-A-C'-B-B-A-G-G-A-E  Please note that C' represents the next octave C | o melo lili.   o otawe pi poka lelesen lipu ni. |
| 14 | As a human (at least, I hope you're human), you probably behave in a way that is unique to you. You likely have a face, torso, arms, and legs. I would imagine you think consciously, with thoughts and opinions based on your life ex | sina ken li pali e noka pi luka sijelo sinpin. mi wile pali e opinio pi koniou sina imakine kepeken ni lon kama sona pi sijelo sina. |
| 15 | how do I pass data from one component to another in the quasar framework. | ni pi pa mi li pali tan kopone wan tawa ante lon ilo pi kuasa. |
| 16 | Nice. Will this code run into an error if a file does not have a file extension? | pona. lipu toki ni li kama pali e ekesinon pi lipipuki lon pakala ala anu seme? |

## Метрики прогона

```json
{
  "messages": 40436,
  "sentences": 230543,
  "words_en": 3408390,
  "words_tp": 2485805,
  "length_ratio": 0.729,
  "sentences_clean_pct": 97.84,
  "messages_clean_pct": 91.11,
  "lexicon_coverage_pct": 99.65,
  "tokens_total": 2485660,
  "tokens_unknown": 8576,
  "violations_by_rule": {
    "tanru_order": 31218,
    "question": 30022,
    "negation": 12679,
    "unknown_word": 8128,
    "particle_pi": 2215,
    "particle_li": 2193,
    "preposition": 2000,
    "word_order": 1041,
    "particle_e": 882,
    "phonology": 448
  },
  "errors_by_rule": {
    "preposition": 2000,
    "word_order": 1041,
    "particle_li": 938,
    "particle_e": 882,
    "phonology": 448
  },
  "top_unknown_tokens": [
    [
      "lipipuki",
      2468
    ],
    [
      "isona",
      1600
    ],
    [
      "powen",
      1406
    ],
    [
      "e",
      839
    ],
    [
      "linusa",
      659
    ],
    [
      "easier",
      599
    ],
    [
      "winona",
      514
    ],
    [
      "summary",
      486
    ],
    [
      "risk",
      484
    ],
    [
      "theory",
      483
    ],
    [
      "far",
      481
    ],
    [
      "along",
      481
    ],
    [
      "series",
      478
    ],
    [
      "relevant",
      477
    ],
    [
      "reach",
      475
    ],
    [
      "seen",
      474
    ],
    [
      "particular",
      471
    ],
    [
      "throughout",
      467
    ],
    [
      "interesting",
      465
    ],
    [
      "inli",
      464
    ],
    [
      "explore",
      462
    ],
    [
      "etc",
      461
    ],
    [
      "maintain",
      455
    ],
    [
      "date",
      455
    ],
    [
      "location",
      453
    ],
    [
      "scientific",
      453
    ],
    [
      "built",
      452
    ],
    [
      "complete",
      452
    ],
    [
      "benefits",
      449
    ],
    [
      "previous",
      447
    ],
    [
      "original",
      447
    ],
    [
      "written",
      447
    ],
    [
      "bit",
      447
    ],
    [
      "fun",
      442
    ],
    [
      "traditional",
      442
    ],
    [
      "care",
      440
    ],
    [
      "analysis",
      439
    ],
    [
      "address",
      438
    ],
    [
      "yet",
      436
    ],
    [
      "conclusion",
      435
    ]
  ],
  "loans_total": 26769
}
```

## Золотой тест: примеры из lipu pu

```bash
python3 scripts/07_book_examples.py
```

63 пары из книги jan Sonja Lang; BLEU-4 = 14.47, точное совпадение = 39.7%.
