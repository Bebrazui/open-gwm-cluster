"""Rule-based переводчик английский -> токи пона.

Принцип: разбираем английское предложение на подлежащее / сказуемое /
дополнение / предложные группы, затем собираем токи-поновскую конструкцию
по правилам lipu pu:

  * подлежащее — существительное-фраза (голова + модификаторы, порядок
    модификаторов обратный английскому: "jan pona");
  * li отделяет подлежащее от сказуемого (после mi/sina li не ставится);
  * предлоги: kepeken, lon, tan, tawa;
  * прямое дополнение — с частицей e;
  * отрицание — частица ala после глагола ("moku ala");
  * вопрос: wh-вопрос — "seme" в позиции неизвестного, yes/no — "anu seme";
  * неизвестные слова — nimi tawa (правила Lesson 9), помечаются как заимствования.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from . import english as en
from .en_lexicon import (
    TP_ADJ,
    TP_ADV,
    TP_NOUN,
    TP_NUMBER,
    TP_PARTICLE,
    TP_PREVERB,
    TP_VERB,
    EnLexicon,
)
from .lexicon import Lexicon
from .phonology import to_nimi_tawa

#: Местоимения токи пона (после них li не ставится).
PRONOUNS_NO_LI = {"mi", "sina"}

#: Глаголы-связки: дополнение после них — предикат, а не объект.
LINKING_VERBS = {"be", "seem", "appear", "become", "remain", "stay", "feel"}

#: Вспомогательные глаголы-связки, не дающие отдельного сказуемого.
BE_FORMS = {"am", "is", "are", "was", "were", "be", "been", "being"}

#: Отрицания.
NEGATIONS = {"not", "no", "never", "none", "neither"}

#: Вопросительные слова.
WH_WORDS = {"what", "which", "who", "whom", "where", "when", "why", "how"}


@dataclass
class Stats:
    sentences: int = 0
    words_in: int = 0
    words_out: int = 0
    unknown_words: int = 0
    loans: int = 0
    dropped: int = 0
    sentences_empty: int = 0
    loans_set: set[str] = field(default_factory=set)
    unknown_set: set[str] = field(default_factory=set)

    def merge(self, other: "Stats") -> None:
        self.sentences += other.sentences
        self.words_in += other.words_in
        self.words_out += other.words_out
        self.unknown_words += other.unknown_words
        self.loans += other.loans
        self.dropped += other.dropped
        self.sentences_empty += other.sentences_empty
        self.loans_set |= other.loans_set
        self.unknown_set |= other.unknown_set


@dataclass
class Item:
    """Элемент разбора: либо слово с переводом, либо многословная фраза."""

    en: str
    tp: list[str] = field(default_factory=list)
    tp_pos: str | None = None
    en_pos: str = "NOUN"
    is_phrase: bool = False


def number_to_tp(n: int) -> list[str]:
    """Число по системе lipu pu (Lesson 12): 1 wan, 2 tu, 5 luka, 20 mute, 100 ale."""
    if n <= 0:
        return ["ala"]
    if n > 100_000:
        # очень большие числа не разворачиваем в тысячи слов
        return ["ale"] * 10 + ["mute"] * 10
    out: list[str] = []
    if n >= 100:
        out += ["ale"] * (n // 100)
        n %= 100
    if n >= 20:
        out += ["mute"] * (n // 20)
        n %= 20
    if n >= 5:
        out += ["luka"] * (n // 5)
        n %= 5
    if n >= 2:
        out += ["tu"] * (n // 2)
        n %= 2
    if n == 1:
        out += ["wan"]
    return out or ["ala"]


class Translator:
    def __init__(self, tp_lexicon: Lexicon, en_lexicon: EnLexicon):
        self.tp = tp_lexicon
        self.en = en_lexicon

    # ------------------------------------------------------------------
    # публичный API
    # ------------------------------------------------------------------
    def translate(self, text: str) -> tuple[str, Stats]:
        stats = Stats()
        segments = en.split_segments(text)
        out_parts: list[str] = []
        for seg in segments:
            if seg.translatable:
                out_parts.append(self._translate_prose(seg.text, stats))
            else:
                out_parts.append(seg.text)
        return "".join(out_parts), stats

    # ------------------------------------------------------------------
    # текст -> предложения
    # ------------------------------------------------------------------
    def _translate_prose(self, text: str, stats: Stats) -> str:
        out_lines: list[str] = []
        for line in text.split("\n"):
            if not line.strip():
                out_lines.append("")
                continue
            indent, marker = en.split_list_item(line)
            content = line[len(indent) + len(marker) :]
            translated = self._translate_line(content, stats)
            out_lines.append(f"{indent}{marker}{translated}")
        return "\n".join(out_lines)

    def _translate_line(self, line: str, stats: Stats) -> str:
        out: list[str] = []
        for sentence in en.split_sentences(line):
            if not sentence.strip():
                continue
            stats.sentences += 1
            stats.words_in += len(sentence.split())
            tp_sentence = self._translate_sentence(sentence, stats)
            if tp_sentence:
                stats.words_out += len(tp_sentence.split())
                out.append(tp_sentence)
            else:
                stats.sentences_empty += 1
        return " ".join(out)

    # ------------------------------------------------------------------
    # предложение
    # ------------------------------------------------------------------
    def _translate_sentence(self, sentence: str, stats: Stats) -> str:
        raw = sentence.strip()
        if not raw:
            return ""
        is_question = raw.endswith("?")
        core = raw.rstrip("?!. ").strip()
        if not core:
            return ""

        text = en.expand_contractions(core)
        tokens = [t for t in en.tokenize(text) if t.kind != "punct"]
        if not tokens:
            return ""
        words = [t.lower for t in tokens]

        # «please» в конце предложения
        trailing_please = words and words[-1] == "please"
        if trailing_please:
            words = words[:-1]

        # 1) фраза, покрывающая всё предложение ("thank you", "how are you")
        phrase = self.en.match_phrase(words, 0)
        if phrase and phrase[1] == len(words):
            body = " ".join(phrase[0])
            return body + ("?" if is_question else ".")

        # 2) wh-вопрос: первое слово
        wh_word: str | None = None
        if words and words[0] in WH_WORDS:
            if is_question or words[0] != "how":
                wh_word = words[0]
                words = words[1:]
            else:
                # «how» в утверждении («I know how to write») — вводное слово
                words = words[1:]
            # «how many/much» -> «mute»
            if wh_word == "how" and words and words[0] in {"many", "much"}:
                wh_word = "how_many"
                words = words[1:]

        # 3) «there is/are ...»
        there_mode = False
        if len(words) >= 2 and words[0] == "there" and words[1] in BE_FORMS:
            there_mode = True
            words = ["there"] + words[2:]

        items = self._to_items(words, stats)
        if not items:
            return ""

        # 4) приветствия и вежливые слова
        prefix, items = self._take_leading(items)
        if trailing_please:
            prefix = f"{prefix} o".strip()

        if there_mode:
            subject = [Item(en="there", tp=["ni"], tp_pos=TP_NOUN, en_pos="PRON")]
            verb_group = [Item(en="is", tp=[], tp_pos=None, en_pos="AUX")]
            complement = items[2:]
        else:
            subject, verb_group, complement = self._split(items)

        if verb_group is None:
            # нет глагола — предложение сводится к NP или к конструкции-фразе
            if subject and subject[0].en_pos == "CLAUSE":
                body = " ".join(subject[0].tp)
                obj_words, prep_phrases, adjuncts = self._parse_complement(complement, stats)
                if obj_words:
                    body += " e " + " ".join(obj_words)
                for prep, np_words in prep_phrases:
                    if prep:
                        body += " " + prep
                    body += " " + " ".join(np_words)
                if adjuncts:
                    body += " " + " ".join(adjuncts)
                body = body.strip()
                result = f"{prefix} {body}".strip() if prefix else body
                result = self._dedupe(result)
                return result + ("?" if is_question else ".")
            body = " ".join(self._build_np(subject, stats))
            while body.split() and body.split()[-1] in {"lon", "tawa", "tan", "kepeken", "pi"}:
                body = " ".join(body.split()[:-1])
            if not body or all(w in {"a", "e", "en", "kin", "la", "li", "o", "pi"} for w in body.split()):
                return ""
            if wh_word:
                body = f"{self._wh_phrase(wh_word)} {body}".strip()
            body = f"{prefix} {body}".strip() if prefix else body
            body = self._dedupe(body)
            return body + ("?" if is_question else ".")

        preverbs, main_verb, linking, negated = self._verb_group(verb_group)

        # фраза-конструкция («help me») — её слова заменяют сказуемое
        clause_words: list[str] = []
        for item in complement:
            if item.en_pos == "CLAUSE":
                clause_words = list(item.tp)
                break
        if clause_words and (main_verb is None or main_verb.en == "do"):
            main_verb = Item(
                en="clause",
                tp=clause_words,
                tp_pos=TP_VERB,
                en_pos="VERB",
            )
            complement = [it for it in complement if it.en_pos != "CLAUSE"]

        # 5) инфинитив: "want to learn X" -> wile + sona
        complement = list(complement)
        if (
            len(complement) >= 2
            and complement[0].en == "to"
            and complement[1].en_pos == "VERB"
        ):
            infinitive = complement[1]
            if main_verb is None:
                main_verb = infinitive
            complement = complement[2:]

        if main_verb is None and not linking:
            # глагола нет («do it») — используем универсальный «pali»
            main_verb = Item(en="do", tp=["pali"], tp_pos=TP_VERB, en_pos="VERB")

        tp_subject = self._build_np(subject, stats)
        tp_preverbs = [w for p in preverbs for w in p]

        parts: list[str] = []
        if tp_subject:
            parts.extend(tp_subject)
            # li не ставится только после одиночного местоимения (mi, sina)
            if not (len(tp_subject) == 1 and tp_subject[0] in PRONOUNS_NO_LI):
                parts.append("li")
        if tp_preverbs:
            parts.extend(tp_preverbs)
            if negated:
                parts.append("ala")

        if main_verb is None:
            # связка без лексического глагола: "you are good" -> "sina pona"
            pred_words, prep_phrases, adjuncts = self._parse_complement(complement, stats)
            parts.extend(pred_words)
            for prep, np_words in prep_phrases:
                if prep:
                    parts.append(prep)
                parts.extend(np_words)
            parts.extend(adjuncts)
        else:
            parts.extend(main_verb.tp)
            if negated and not tp_preverbs:
                parts.append("ala")
            obj_words, prep_phrases, adjuncts = self._parse_complement(complement, stats)
            if obj_words:
                if main_verb.tp and main_verb.tp[0] in {"kepeken", "lon", "tan", "tawa"}:
                    parts.extend(obj_words)
                else:
                    parts.append("e")
                    parts.extend(obj_words)
            for prep, np_words in prep_phrases:
                if prep:
                    parts.append(prep)
                parts.extend(np_words)
            parts.extend(adjuncts)

        body = " ".join(p for p in parts if p).strip()
        # убираем «хвостовые» предлоги без объекта: "lon", "tawa", "tan", "kepeken", "pi"
        while body.split() and body.split()[-1] in {"lon", "tawa", "tan", "kepeken", "pi"}:
            body = " ".join(body.split()[:-1])
        # предложение без содержательных слов (только частицы) — выбрасываем
        if not body or all(w in {"a", "e", "en", "kin", "la", "li", "o", "pi"} for w in body.split()):
            return ""

        # императив без подлежащего
        if not tp_subject and not wh_word and not prefix.endswith("o"):
            body = f"o {body}".strip()

        # вопрос
        if is_question:
            if wh_word:
                wh_words = self._wh_phrase(wh_word)
                if wh_word in {"who", "whom", "what", "which", "how_many"}:
                    body = f"{wh_words} {body}".strip()
                else:
                    body = f"{body} {wh_words}".strip()
            else:
                body = f"{body} anu seme".strip()

        result = f"{prefix} {body}".strip() if prefix else body
        result = self._dedupe(result)
        return result + ("?" if is_question else ".")

    # ------------------------------------------------------------------
    # разбор
    # ------------------------------------------------------------------
    def _to_items(self, words: list[str], stats: Stats) -> list[Item]:
        """Слова -> элементы с учётом фразовых шаблонов."""
        items: list[Item] = []
        i = 0
        while i < len(words):
            phrase = self.en.match_phrase(words, i)
            if phrase:
                tp_words, length = phrase
                # фраза-конструкция — целая конструкция, а не имя-группа
                is_clause = " ".join(words[i : i + length]) in self.en.clause_phrases
                items.append(
                    Item(
                        en=" ".join(words[i : i + length]),
                        tp=list(tp_words),
                        tp_pos=None if length == 1 else TP_NOUN,
                        en_pos="CLAUSE" if is_clause else "PHRASE",
                        is_phrase=True,
                    )
                )
                i += length
                continue
            word = words[i]
            if word == "how" and i + 1 < len(words) and words[i + 1] == "to":
                # «how to ...» — вводная конструкция
                stats.dropped += 1
                i += 1
                continue
            if word.isdecimal():
                items.append(
                    Item(en=word, tp=number_to_tp(int(word)), tp_pos=TP_NUMBER, en_pos="NUM")
                )
                i += 1
                continue
            entry = self.en.lookup(word)
            if entry is None:
                loan = to_nimi_tawa(word)
                if loan:
                    known = self.tp.get(loan)
                    if known:
                        tp_pos = TP_ADJ if "ADJECTIVE" in known.pos else TP_NOUN
                        en_pos = "ADJ" if tp_pos == TP_ADJ else "NOUN"
                    else:
                        tp_pos, en_pos = TP_NOUN, "NOUN"
                    items.append(Item(en=word, tp=[loan], tp_pos=tp_pos, en_pos=en_pos))
                    stats.loans += 1
                    stats.loans_set.add(loan)
                    stats.unknown_words += 1
                    stats.unknown_set.add(word)
                else:
                    stats.dropped += 1
                i += 1
                continue
            items.append(
                Item(
                    en=word,
                    tp=list(entry.tp),
                    tp_pos=entry.tp_pos,
                    en_pos=entry.en_pos,
                )
            )
            i += 1
        return items

    def _take_leading(self, items: list[Item]) -> tuple[str, list[Item]]:
        """Вынести приветствия и вежливые слова в начало."""
        prefix_parts: list[str] = []
        while items:
            item = items[0]
            if item.en in {"hello", "hi", "hey"}:
                prefix_parts.append("toki")
                items = items[1:]
                continue
            if item.en in {"thanks", "thank"}:
                prefix_parts.append("pona")
                items = items[1:]
                continue
            if item.en == "please":
                prefix_parts.append("o")
                items = items[1:]
                continue
            if item.en == "sorry":
                prefix_parts.append("pilin ike")
                items = items[1:]
                continue
            if item.en in {"okay", "ok"}:
                prefix_parts.append("pona")
                items = items[1:]
                continue
            break
        return " ".join(prefix_parts), items

    def _split(self, items: list[Item]) -> tuple[list[Item], list[Item] | None, list[Item]]:
        """Разделить на подлежащее, глагольную группу и дополнение."""
        i = 0
        verb_group: list[Item] = []
        # ведущие aux/modal (вопросительный порядок: "can you ...?")
        while i < len(items) and items[i].en_pos in {"MODAL", "AUX"}:
            verb_group.append(items[i])
            i += 1
        # подлежащее
        subject: list[Item] = []
        while i < len(items):
            item = items[i]
            if item.en_pos == "CLAUSE" and not subject:
                # фраза-конструкция в начале («i think ...», «let me ...»)
                subject.append(item)
                i += 1
                break
            if (
                item.en_pos in {"VERB", "MODAL", "AUX", "PREP", "CLAUSE"}
                or item.en in NEGATIONS
            ):
                break
            subject.append(item)
            i += 1
        # глагольная группа
        while i < len(items):
            item = items[i]
            if item.en_pos in {"MODAL", "AUX", "VERB"} or item.en in NEGATIONS:
                verb_group.append(item)
                i += 1
                continue
            break
        complement = items[i:]
        if not verb_group:
            return subject, None, complement
        return subject, verb_group, complement

    def _verb_group(
        self, group: list[Item]
    ) -> tuple[list[list[str]], Item | None, bool, bool]:
        """Разобрать глагольную группу: предглаголы, главный глагол, отрицание."""
        preverbs: list[list[str]] = []
        main: Item | None = None
        negated = False
        linking = False
        for item in group:
            if item.en in NEGATIONS:
                negated = True
                continue
            if item.en_pos == "AUX":
                if item.en in BE_FORMS:
                    linking = True
                continue
            if main is None:
                if item.en_pos == "MODAL" or item.tp_pos == TP_PREVERB:
                    preverbs.append(list(item.tp))
                    continue
                main = item
        if main is not None and main.en in LINKING_VERBS:
            linking = True
        return preverbs, main, linking, negated

    def _parse_complement(
        self, complement: list[Item], stats: Stats
    ) -> tuple[list[str], list[tuple[str, list[str]]], list[str]]:
        """Разобрать дополнение: объект, предложные группы, наречные дополнения."""
        obj_items: list[Item] = []
        prep_phrases: list[tuple[str, list[str]]] = []
        adjuncts: list[str] = []

        i = 0
        while i < len(complement):
            item = complement[i]
            if item.en_pos == "PREP" and item.tp:
                np_items, i = self._collect_np(complement, i + 1)
                np_words = self._build_np(np_items, stats)
                if np_words:
                    prep_phrases.append((" ".join(item.tp), np_words))
                continue
            if item.en_pos == "ADV":
                if item.tp:
                    tp_words = list(item.tp)
                    if tp_words and tp_words[0] == "tenpo":
                        tp_words = ["lon"] + tp_words
                    adjuncts.extend(tp_words)
                i += 1
                continue
            if item.en_pos == "CONJ":
                i += 1
                continue
            if item.en_pos == "CLAUSE":
                # фраза-конструкция: её слова добавляются к предикату
                for word in item.tp:
                    prep_phrases.append(("", [word]))
                i += 1
                continue
            np_items, i = self._collect_np(complement, i)
            if not np_items:
                # глагол внутри дополнения — пропускаем, чтобы не зациклиться
                i += 1
            obj_items.extend(np_items)

        obj_words = self._build_np(obj_items, stats)
        return obj_words, prep_phrases, adjuncts

    def _collect_np(self, items: list[Item], index: int) -> tuple[list[Item], int]:
        """Собрать имя-группу: DET/ADJ/NOUN/PRON/NUM/ADV до глагола или предлога."""
        taken: list[Item] = []
        i = index
        while i < len(items):
            item = items[i]
            if item.en_pos in {"VERB", "PREP", "CONJ", "MODAL", "AUX", "CLAUSE"}:
                break
            taken.append(item)
            i += 1
        return taken, i

    # ------------------------------------------------------------------
    # имя-группа
    # ------------------------------------------------------------------
    def _build_np(self, items: list[Item], stats: Stats) -> list[str]:
        """Собрать NP по правилам lipu pu: голова + модификаторы (обратный порядок)."""
        if not items:
            return []
        head: Item | None = None
        modifiers: list[Item] = []
        numbers: list[Item] = []
        adverbs: list[Item] = []
        for item in items:
            if item.en_pos in {"NOUN", "PRON"} and item.tp_pos != "prep":
                # в английском имя-фразе голова — последнее существительное
                # ("computer program" -> program, "the big car" -> car)
                if head is not None:
                    modifiers.append(head)
                head = item
                continue
            if head is None and item.en_pos not in {"NUM", "ADV"}:
                modifiers.append(item)
                continue
            if item.en_pos == "NUM":
                numbers.append(item)
            elif item.en_pos == "ADV":
                adverbs.append(item)
            else:
                modifiers.append(item)
        if head is None:
            head = modifiers.pop(0) if modifiers else None
            if head is None:
                return []

        head_words = list(head.tp) if head.tp else []
        if not head_words:
            return []

        mod_words: list[str] = []
        noun_mod = False
        for mod in reversed(modifiers):
            if not mod.tp:
                continue
            if (
                mod.tp_pos in (TP_NOUN, TP_NUMBER)
                and not mod.is_phrase
                and not (len(mod.tp) == 1 and mod.tp[0] in {"mi", "sina", "ona", "ni"})
            ):
                noun_mod = True
            mod_words.extend(mod.tp)

        out: list[str] = list(head_words)
        if mod_words:
            if noun_mod:
                out.append("pi")
            out.extend(mod_words)
        for num in numbers:
            out.extend(num.tp)
        for adv in adverbs:
            out.extend(adv.tp)
        return out

    # ------------------------------------------------------------------
    # вопросы
    # ------------------------------------------------------------------
    def _wh_phrase(self, word: str) -> str:
        mapping = {
            "what": "seme",
            "which": "seme",
            "who": "jan seme",
            "whom": "jan seme",
            "where": "lon seme",
            "when": "tenpo seme",
            "why": "tan seme",
            "how": "li'u",
            "how_many": "mute",
        }
        return mapping.get(word, "seme")

    # ------------------------------------------------------------------
    # утилиты
    # ------------------------------------------------------------------
    @staticmethod
    def _dedupe(text: str) -> str:
        words = text.split()
        out: list[str] = []
        for w in words:
            if out and out[-1] == w:
                continue
            out.append(w)
        return " ".join(out)

    def known_words(self) -> set[str]:
        return set(self.tp.words) | set(self.tp.aliases)
