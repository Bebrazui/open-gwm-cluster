"""Экспорт переведённого датасета.

Формат вывода — jsonl, совместимый с OASST1 (все исходные поля плюс
``text_toki_pona``), плюс сводный отчёт в json.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable

from .pipeline import TranslationRecord


def export_jsonl(records: Iterable[TranslationRecord], path: str | Path) -> int:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    count = 0
    with open(path, "wt", encoding="utf-8") as fh:
        for rec in records:
            fh.write(json.dumps(rec.to_json(), ensure_ascii=False) + "\n")
            count += 1
    return count


def export_hf_style(records: Iterable[TranslationRecord], path: str | Path) -> int:
    """Формат, повторяющий раскладку OpenAssistant/oasst1 (messages + trees)."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    count = 0
    with open(path, "wt", encoding="utf-8") as fh:
        for rec in records:
            payload = {
                "message_id": rec.message_id,
                "role": rec.role,
                "lang": rec.lang,
                "text": rec.text_en,
                "text_toki_pona": rec.text_tp,
                "violations": rec.violations,
            }
            fh.write(json.dumps(payload, ensure_ascii=False) + "\n")
            count += 1
    return count


def export_summary(metrics: dict, path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(metrics, ensure_ascii=False, indent=2), encoding="utf-8")
