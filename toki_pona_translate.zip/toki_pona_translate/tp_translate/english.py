"""Разбор английского текста: токенизация, предложения, сокращения, markdown.

Нужен для rule-based перевода на токи пона: сначала разбираем структуру
предложения (подлежащее / сказуемое / дополнение / предложные группы),
потом строим токи-поновскую конструкцию.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

# --------------------------------------------------------------------------
# markdown: код и ссылки оставляем как есть
# --------------------------------------------------------------------------

CODE_BLOCK_RE = re.compile(r"```.*?```", re.DOTALL)
INLINE_CODE_RE = re.compile(r"`[^`\n]+`")
URL_RE = re.compile(r"https?://\S+")
HTML_TAG_RE = re.compile(r"</?[a-zA-Z][^>]*>")


@dataclass
class Segment:
    """Фрагмент текста: переводимый или сохраняемый как есть."""

    text: str
    translatable: bool
    kind: str = "prose"  # prose | code | url | html


def split_segments(text: str) -> list[Segment]:
    """Разбить текст на переводимые куски и код/ссылки (их не трогаем)."""
    segments: list[Segment] = []
    pos = 0
    pattern = re.compile(
        "|".join(
            [
                CODE_BLOCK_RE.pattern,
                INLINE_CODE_RE.pattern,
                URL_RE.pattern,
                HTML_TAG_RE.pattern,
            ]
        ),
        re.DOTALL,
    )
    for match in pattern.finditer(text):
        if match.start() > pos:
            chunk = text[pos : match.start()]
            if chunk.strip():
                segments.append(Segment(chunk, True, "prose"))
        raw = match.group(0)
        if raw.startswith("```"):
            kind = "code"
        elif raw.startswith("`"):
            kind = "code"
        elif raw.startswith("http"):
            kind = "url"
        else:
            kind = "html"
        segments.append(Segment(raw, False, kind))
        pos = match.end()
    if pos < len(text):
        chunk = text[pos:]
        if chunk.strip():
            segments.append(Segment(chunk, True, "prose"))
    return segments


# --------------------------------------------------------------------------
# сокращения
# --------------------------------------------------------------------------

CONTRACTIONS = {
    "i'm": "i am",
    "i've": "i have",
    "i'll": "i will",
    "i'd": "i would",
    "you're": "you are",
    "you've": "you have",
    "you'll": "you will",
    "you'd": "you would",
    "he's": "he is",
    "she's": "she is",
    "it's": "it is",
    "we're": "we are",
    "we've": "we have",
    "we'll": "we will",
    "they're": "they are",
    "they've": "they have",
    "they'll": "they will",
    "that's": "that is",
    "there's": "there is",
    "here's": "here is",
    "what's": "what is",
    "who's": "who is",
    "let's": "let us",
    "isn't": "is not",
    "aren't": "are not",
    "wasn't": "was not",
    "weren't": "were not",
    "don't": "do not",
    "doesn't": "does not",
    "didn't": "did not",
    "can't": "can not",
    "cannot": "can not",
    "couldn't": "could not",
    "won't": "will not",
    "wouldn't": "would not",
    "shouldn't": "should not",
    "mustn't": "must not",
    "don't": "do not",
    "hasn't": "has not",
    "haven't": "have not",
    "hadn't": "had not",
    "ain't": "is not",
    "y'all": "you all",
}


#: Типографские лигатуры PDF -> обычные буквы.
LIGATURES = {
    "\ufb00": "ff", "\ufb01": "fi", "\ufb02": "fl", "\ufb03": "ffi",
    "\ufb04": "ffl", "\ufb05": "st", "\ufb06": "st",
}


def normalize_text(text: str) -> str:
    """Нормализация типографики: апострофы, кавычки, лигатуры, nbsp."""
    for src, dst in LIGATURES.items():
        text = text.replace(src, dst)
    return (
        text.replace("\u2019", "'")
        .replace("\u2018", "'")
        .replace("\u02bc", "'")
        .replace("\u201c", '"')
        .replace("\u201d", '"')
        .replace("\u00a0", " ")
    )


#: обратная совместимость
normalize_quotes = normalize_text


def expand_contractions(text: str) -> str:
    text = normalize_text(text)

    def repl(m: re.Match) -> str:
        word = m.group(0).lower()
        return CONTRACTIONS.get(word, word)

    return re.sub(r"[A-Za-z]+(?:'[A-Za-z]+)?", repl, text)


# --------------------------------------------------------------------------
# токенизация
# --------------------------------------------------------------------------

TOKEN_RE = re.compile(r"[A-Za-z]+(?:'[A-Za-z]+)?|\d+(?:[.,]\d+)?|[^\sA-Za-z\d]")


@dataclass
class Token:
    text: str
    lower: str
    kind: str  # word | number | punct
    index: int = 0
    tags: set[str] = field(default_factory=set)

    @property
    def is_word(self) -> bool:
        return self.kind == "word"


def tokenize(text: str) -> list[Token]:
    tokens: list[Token] = []
    for i, m in enumerate(TOKEN_RE.finditer(text)):
        raw = m.group(0)
        if raw[0] in "0123456789":
            kind = "number"
        elif raw[0].isalpha():
            kind = "word"
        else:
            kind = "punct"
        tokens.append(Token(raw, raw.lower(), kind, i))
    return tokens


# --------------------------------------------------------------------------
# деление на предложения и строки
# --------------------------------------------------------------------------

_SENT_END = re.compile(r"(?<=[.!?])[\"')\]]*\s+")


def split_sentences(text: str) -> list[str]:
    """Разделить абзац на предложения, сохраняя переводы строк."""
    parts: list[str] = []
    for line in text.split("\n"):
        stripped = line.strip()
        if not stripped:
            parts.append("")
            continue
        # не режем списки и заголовки без завершающей точки
        chunks = _SENT_END.split(stripped)
        buf = ""
        for chunk in chunks:
            buf = (buf + " " + chunk).strip() if buf else chunk
            if buf.endswith((".", "!", "?")):
                parts.append(buf)
                buf = ""
        if buf:
            parts.append(buf)
    return parts


def strip_markdown(text: str) -> str:
    """Убрать markdown-разметку, оставив структуру списков и заголовков."""
    out = re.sub(r"^#{1,6}\s*", "", text, flags=re.MULTILINE)
    out = re.sub(r"^\s*[-*+]\s+", "", out, flags=re.MULTILINE)
    out = re.sub(r"^\s*\d+[.)]\s+", "", out, flags=re.MULTILINE)
    out = out.replace("**", "").replace("__", "")
    out = out.replace("*", "").replace("_", "")
    out = re.sub(r"\[([^\]]+)\]\([^)]*\)", r"\1", out)
    return out


def split_list_item(line: str) -> tuple[str, str]:
    """Вернуть (отступ, маркер списка/заголовка) для строки.

    Если маркера нет, возвращается ("", "").
    """
    m = re.match(r"^(\s*)([-*+]\s+|\d+[.)]\s+|#{1,6}\s+)", line)
    if not m:
        return "", ""
    return m.group(1), m.group(2)
