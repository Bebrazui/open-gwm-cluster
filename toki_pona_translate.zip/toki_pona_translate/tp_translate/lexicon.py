"""Лексикон токи пона: слова, части речи, глоссы.

Собирается из двух официальных источников:
  * nimi pu — "Toki Pona: The Language of Good" (refs/lipu_pu2.pdf, словарь на
    страницах 140-146);
  * nimi ku — Toki Pona Dictionary (refs/janne_dict.html, 137 слов ku suli).

Результат: refs/lexicon.json (собирается скриптом scripts/02_build_lexicon.py).
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

POS_NOUN = "NOUN"
POS_VERB = "VERB"
POS_ADJ = "ADJECTIVE"
POS_PARTICLE = "PARTICLE"
POS_PREP = "PREPOSITION"
POS_PREVERB = "PRE-VERB"
POS_NUMBER = "NUMBER"
POS_ADVERB = "ADVERB"
POS_INTERJ = "INTERJECTION"

ALL_POS = {
    POS_NOUN,
    POS_VERB,
    POS_ADJ,
    POS_PARTICLE,
    POS_PREP,
    POS_PREVERB,
    POS_NUMBER,
    POS_ADVERB,
    POS_INTERJ,
}


@dataclass
class Entry:
    word: str
    pos: set[str] = field(default_factory=set)
    gloss: str = ""
    sources: set[str] = field(default_factory=set)

    def to_json(self) -> dict:
        return {
            "word": self.word,
            "pos": sorted(self.pos),
            "gloss": self.gloss,
            "sources": sorted(self.sources),
        }


class Lexicon:
    """Словарь токи пона с классами слов."""

    def __init__(self, entries: dict[str, Entry], aliases: dict[str, str] | None = None):
        self.entries = entries
        self.aliases = aliases or {}

    # -- построение -------------------------------------------------------
    @classmethod
    def from_json(cls, path: str | Path) -> "Lexicon":
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        entries = {}
        for w, e in data["words"].items():
            entries[w] = Entry(
                word=w,
                pos=set(e.get("pos", [])),
                gloss=e.get("gloss", ""),
                sources=set(e.get("sources", [])),
            )
        return cls(entries, data.get("aliases", {}))

    def to_json(self) -> dict:
        return {
            "words": {w: e.to_json() for w, e in sorted(self.entries.items())},
            "aliases": dict(sorted(self.aliases.items())),
        }

    def save(self, path: str | Path) -> None:
        Path(path).write_text(
            json.dumps(self.to_json(), ensure_ascii=False, indent=2), encoding="utf-8"
        )

    # -- доступ -----------------------------------------------------------
    def __contains__(self, word: str) -> bool:
        return word in self.entries or word in self.aliases

    def __len__(self) -> int:
        return len(self.entries)

    def get(self, word: str) -> Entry | None:
        if word in self.entries:
            return self.entries[word]
        alias = self.aliases.get(word)
        if alias:
            return self.entries.get(alias)
        return None

    def pos(self, word: str) -> set[str]:
        e = self.get(word)
        return e.pos if e else set()

    def has_pos(self, word: str, pos: str) -> bool:
        return pos in self.pos(word)

    def is_noun(self, word: str) -> bool:
        return POS_NOUN in self.pos(word)

    def is_adjective(self, word: str) -> bool:
        return POS_ADJ in self.pos(word)

    def is_verb(self, word: str) -> bool:
        return POS_VERB in self.pos(word)

    def is_particle(self, word: str) -> bool:
        return POS_PARTICLE in self.pos(word)

    def is_preposition(self, word: str) -> bool:
        return POS_PREP in self.pos(word)

    def is_preverb(self, word: str) -> bool:
        return POS_PREVERB in self.pos(word)

    def is_number(self, word: str) -> bool:
        return POS_NUMBER in self.pos(word)

    @property
    def words(self) -> list[str]:
        return sorted(self.entries)

    @property
    def nouns(self) -> list[str]:
        return sorted(w for w, e in self.entries.items() if POS_NOUN in e.pos)

    @property
    def adjectives(self) -> list[str]:
        return sorted(w for w, e in self.entries.items() if POS_ADJ in e.pos)

    @property
    def verbs(self) -> list[str]:
        return sorted(w for w, e in self.entries.items() if POS_VERB in e.pos)

    @property
    def particles(self) -> list[str]:
        return sorted(w for w, e in self.entries.items() if POS_PARTICLE in e.pos)

    @property
    def prepositions(self) -> list[str]:
        return sorted(w for w, e in self.entries.items() if POS_PREP in e.pos)

    @property
    def preverbs(self) -> list[str]:
        return sorted(w for w, e in self.entries.items() if POS_PREVERB in e.pos)

    def words_with_pos(self, pos: str) -> list[str]:
        return sorted(w for w, e in self.entries.items() if pos in e.pos)
