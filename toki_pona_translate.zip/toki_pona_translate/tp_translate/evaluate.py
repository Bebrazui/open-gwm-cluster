"""Метрики качества перевода на токи пона.

Считаем:
  * покрытие словаря — доля слов перевода, входящих в официальный
    словарь (nimi pu/ku) или помеченных как nimi tawa;
  * грамматическую валидность — доля сообщений и предложений без
    нарушений правил lipu pu;
  * распределение нарушений по правилам;
  * неизвестные слова (кандидаты на пополнение словаря);
  * отношение длины перевода к длине оригинала.
"""

from __future__ import annotations

import collections
from typing import Iterable

from . import english as en
from .grammar import TokiPonaValidator
from .phonology import check_word, tokenize_toki
from .pipeline import TranslationRecord


def evaluate(
    records: Iterable[TranslationRecord],
    validator: TokiPonaValidator | None = None,
    top_n: int = 40,
) -> dict:
    n_messages = 0
    n_sentences = 0
    n_clean_sentences = 0
    n_clean_messages = 0
    words_en = 0
    words_tp = 0
    tokens_total = 0
    tokens_known = 0
    tokens_loan = 0
    tokens_unknown = 0
    rules = collections.Counter()
    errors = collections.Counter()
    unknown_words = collections.Counter()
    violations_by_rule = collections.Counter()
    loan_words = collections.Counter()

    for rec in records:
        n_messages += 1
        words_en += rec.stats.get("words_in", 0)
        words_tp += rec.stats.get("words_out", 0)

        sent_errors = 0
        prose_parts = [
            seg.text for seg in en.split_segments(rec.text_tp) if seg.translatable
        ]
        for sentence in en.split_sentences("\n".join(prose_parts)):
            if not sentence.strip():
                continue
            n_sentences += 1
            problems = validator.check_sentence(sentence) if validator else []
            if not any(p.severity == "error" for p in problems):
                n_clean_sentences += 1
            else:
                sent_errors += 1
            for p in problems:
                violations_by_rule[p.rule] += 1
                if p.severity == "error":
                    errors[p.rule] += 1

        if not sent_errors:
            n_clean_messages += 1

        for v in rec.violations:
            rules[v["rule"]] += 1

        for token in tokenize_toki("\n".join(prose_parts)):
            tokens_total += 1
            if validator and validator._is_known(token):
                tokens_known += 1
            else:
                tokens_unknown += 1
                unknown_words[token] += 1

        for word in rec.stats.get("unknown_source_words", []):
            unknown_words[word] += 1

    metrics = {
        "messages": n_messages,
        "sentences": n_sentences,
        "words_en": words_en,
        "words_tp": words_tp,
        "length_ratio": round(words_tp / words_en, 3) if words_en else 0.0,
        "sentences_clean_pct": round(100 * n_clean_sentences / n_sentences, 2) if n_sentences else 0.0,
        "messages_clean_pct": round(100 * n_clean_messages / n_messages, 2) if n_messages else 0.0,
        "lexicon_coverage_pct": round(100 * tokens_known / tokens_total, 2) if tokens_total else 0.0,
        "tokens_total": tokens_total,
        "tokens_unknown": tokens_unknown,
        "violations_by_rule": dict(violations_by_rule.most_common()),
        "errors_by_rule": dict(errors.most_common()),
        "top_unknown_tokens": unknown_words.most_common(top_n),
    }
    return metrics
