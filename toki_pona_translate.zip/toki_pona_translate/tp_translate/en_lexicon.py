"""Билингвальный словарь английский -> токи пона.

Собирается скриптом scripts/03_build_en_lexicon.py из двух источников:
  * data/curated_en_tp.json — кураторская таблица (функциональные слова,
   частотная лексика, тех-домен);
  * refs/lexicon.json — глоссы официальных словарей токи пона, из которых
    автоматически выравниваются кандидаты EN -> TP.

Кураторская запись всегда выигрывает: если слово описано вручную, глосс
автоматики его не перекрывает.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

#: Классы слов токи пона, которые различаёт генератор.
TP_NOUN = "noun"
TP_ADJ = "adj"
TP_VERB = "verb"
TP_PREVERB = "preverb"
TP_PARTICLE = "particle"
TP_NUMBER = "number"
TP_ADV = "adv"


@dataclass
class EnEntry:
    lemma: str
    tp: list[str] = field(default_factory=list)
    tp_pos: str | None = None
    en_pos: str = "NOUN"
    tags: set[str] = field(default_factory=set)
    source: str = "curated"

    @property
    def tp_phrase(self) -> str:
        return " ".join(self.tp)


class EnLexicon:
    def __init__(
        self,
        entries: dict[str, EnEntry],
        phrases: dict[str, list[str]] | None = None,
        clause_phrases: set[str] | None = None,
    ):
        self.entries = entries
        self.phrases = phrases or {}
        self.clause_phrases = clause_phrases or set()
        self._max_phrase_len = max((len(p.split()) for p in self.phrases), default=0)

    @classmethod
    def from_json(cls, path: str | Path) -> "EnLexicon":
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        entries = {}
        for lemma, e in data["entries"].items():
            tp = e.get("tp")
            if tp is None:
                tp_words: list[str] = []
            elif isinstance(tp, str):
                tp_words = tp.split()
            else:
                tp_words = list(tp)
            entries[lemma] = EnEntry(
                lemma=lemma,
                tp=tp_words,
                tp_pos=e.get("tp_pos"),
                en_pos=e.get("en_pos", "NOUN"),
                tags=set(e.get("tags", [])),
                source=e.get("source", "curated"),
            )
        phrases = {k: v for k, v in data.get("phrases", {}).items()}
        clauses = set(data.get("clause_phrases", []))
        return cls(entries, phrases, clauses)

    def save(self, path: str | Path) -> None:
        payload = {
            "entries": {
                lemma: {
                    "tp": e.tp or None,
                    "tp_pos": e.tp_pos,
                    "en_pos": e.en_pos,
                    "tags": sorted(e.tags),
                    "source": e.source,
                }
                for lemma, e in sorted(self.entries.items())
            },
            "phrases": self.phrases,
            "clause_phrases": sorted(self.clause_phrases),
        }
        Path(path).write_text(
            json.dumps(payload, ensure_ascii=False, indent=1), encoding="utf-8"
        )

    def lookup(self, word: str) -> EnEntry | None:
        """Найти слово с учётом английских окончаний (eat -> eating, eats)."""
        entry = self.entries.get(word)
        if entry is not None:
            return entry
        for cand in self.candidates(word):
            entry = self.entries.get(cand)
            if entry is not None:
                return entry
        return None

    def candidates(self, word: str) -> list[str]:
        """Возможные основы слова (от длинных вариантов к коротким)."""
        if len(word) <= 3:
            return []
        out: list[str] = []
        if word.endswith("ies") and len(word) > 4:
            out.append(word[:-3] + "y")
        if word.endswith("ing") and len(word) > 5:
            base = word[:-3]
            out.append(base)
            if not base.endswith("e"):
                out.append(base + "e")
            if len(base) > 2 and base[-1] == base[-2]:
                out.append(base[:-1])
        if word.endswith("ed") and len(word) > 4:
            base = word[:-2]
            out.append(base)
            if not base.endswith("e"):
                out.append(base + "e")
            if len(base) > 2 and base[-1] == base[-2]:
                out.append(base[:-1])
        if word.endswith("ies") and len(word) > 4:
            out.append(word[:-3] + "i")
        if word.endswith("es") and len(word) > 4:
            out.append(word[:-2])
            if not word[:-2].endswith("e"):
                out.append(word[:-1])
        if word.endswith("s") and not word.endswith("ss") and len(word) > 3:
            out.append(word[:-1])
        if word.endswith("er") and len(word) > 4:
            out.append(word[:-2])
            out.append(word[:-1])
        if word.endswith("est") and len(word) > 5:
            out.append(word[:-3])
            out.append(word[:-2])
        if word.endswith("ly") and len(word) > 4:
            out.append(word[:-2])
        if word.endswith("y") and len(word) > 3:
            out.append(word[:-1])
            out.append(word[:-1] + "e")
        seen: set[str] = set()
        return [c for c in out if not (c in seen or seen.add(c))]

    def is_verb(self, word: str) -> bool:
        e = self.entries.get(word)
        return bool(e and e.en_pos == "VERB")

    def is_aux(self, word: str) -> bool:
        e = self.entries.get(word)
        return bool(e and e.en_pos == "AUX")

    def is_modal(self, word: str) -> bool:
        e = self.entries.get(word)
        return bool(e and e.en_pos == "MODAL")

    def is_prep(self, word: str) -> bool:
        e = self.entries.get(word)
        return bool(e and e.en_pos == "PREP")

    def is_adj(self, word: str) -> bool:
        e = self.entries.get(word)
        return bool(e and e.en_pos == "ADJ")

    def is_noun(self, word: str) -> bool:
        e = self.entries.get(word)
        return bool(e and e.en_pos == "NOUN")

    def is_adv(self, word: str) -> bool:
        e = self.entries.get(word)
        return bool(e and e.en_pos == "ADV")

    def match_phrase(self, words: list[str], index: int) -> tuple[list[str], int] | None:
        """Самый длинный многословный фразовый шаблон, начиная с index."""
        if self._max_phrase_len == 0:
            return None
        for length in range(min(self._max_phrase_len, len(words) - index), 0, -1):
            key = " ".join(words[index : index + length])
            if key in self.phrases:
                return list(self.phrases[key]), length
        return None
