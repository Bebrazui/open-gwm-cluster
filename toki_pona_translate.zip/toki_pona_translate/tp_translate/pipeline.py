"""Прогон перевода по корпусу с кэшем и чекпоинтами.

Перевод — чистый Python, поэтому идёт быстро; кэш (jsonl) позволяет
докачивать/перезапускать без потери уже сделанной работы.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, Iterator

from .corpora import Message
from .grammar import TokiPonaValidator, Violation
from .translator import Stats, Translator


@dataclass
class TranslationRecord:
    message_id: str
    role: str
    lang: str
    text_en: str
    text_tp: str
    violations: list[dict] = field(default_factory=list)
    stats: dict = field(default_factory=dict)
    version: str = ""

    def to_json(self) -> dict:
        return {
            "message_id": self.message_id,
            "version": self.version,
            "role": self.role,
            "lang": self.lang,
            "text_en": self.text_en,
            "text_toki_pona": self.text_tp,
            "violations": self.violations,
            "stats": self.stats,
        }


class TranslationPipeline:
    """Переводит сообщения корпуса и проверяет грамматику результата."""

    def __init__(
        self,
        translator: Translator,
        validator: TokiPonaValidator | None = None,
        cache_path: str | Path | None = None,
        validate: bool = True,
        version: str = "",
    ):
        self.translator = translator
        self.validator = validator
        self.cache_path = Path(cache_path) if cache_path else None
        self.validate = validate
        #: версия словарей: при её изменении кэш перестаёт использоваться
        self.version = version

    # ------------------------------------------------------------------
    def load_cache(self) -> dict[str, dict]:
        """Прочитать уже переведённые сообщения из кэша."""
        cache: dict[str, dict] = {}
        if not self.cache_path or not self.cache_path.exists():
            return cache
        with open(self.cache_path, "rt", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if self.version and data.get("version") != self.version:
                    continue  # словари изменились — переводим заново
                cache[data["message_id"]] = data
        return cache

    def _append_cache(self, record: TranslationRecord) -> None:
        if not self.cache_path:
            return
        self.cache_path.parent.mkdir(parents=True, exist_ok=True)
        payload = record.to_json()
        payload["version"] = self.version
        with open(self.cache_path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(payload, ensure_ascii=False) + "\n")

    # ------------------------------------------------------------------
    def run(
        self,
        messages: Iterable[Message],
        limit: int | None = None,
        progress_every: int = 2000,
        on_progress=None,
    ) -> Iterator[TranslationRecord]:
        """Перевести сообщения; уже переведённые берутся из кэша."""
        cache = self.load_cache()
        done = 0
        started = time.time()
        for message in messages:
            if message.message_id in cache:
                data = cache[message.message_id]
                yield TranslationRecord(
                    message_id=data["message_id"],
                    role=data.get("role", ""),
                    lang=data.get("lang", ""),
                    text_en=data.get("text_en", ""),
                    text_tp=data.get("text_toki_pona", ""),
                    violations=data.get("violations", []),
                    stats=data.get("stats", {}),
                )
                done += 1
                if limit and done >= limit:
                    return
                continue

            text_tp, stats = self.translator.translate(message.text)
            if self.validator is not None and stats.loans_set:
                # заимствования (nimi tawa) — допустимые слова токи пона
                self.validator.known_loans.update(stats.loans_set)
            violations = self._validate(text_tp, stats)
            record = TranslationRecord(
                message_id=message.message_id,
                role=message.role,
                lang=message.lang,
                text_en=message.text,
                text_tp=text_tp,
                violations=violations,
                stats={
                    "sentences": stats.sentences,
                    "words_in": stats.words_in,
                    "words_out": stats.words_out,
                    "unknown_words": stats.unknown_words,
                    "loans": stats.loans,
                    "dropped": stats.dropped,
                    "errors": sum(1 for v in violations if v["severity"] == "error"),
                    "warnings": sum(1 for v in violations if v["severity"] == "warning"),
                    "loan_words": sorted(stats.loans_set),
                    "unknown_source_words": sorted(stats.unknown_set),
                },
            )
            record.version = self.version
            self._append_cache(record)
            yield record
            done += 1
            if progress_every and done % progress_every == 0 and on_progress:
                elapsed = time.time() - started
                on_progress(done, elapsed)
            if limit and done >= limit:
                return

    # ------------------------------------------------------------------
    def _validate(self, text_tp: str, stats: Stats) -> list[dict]:
        if not self.validate or self.validator is None:
            return []
        out: list[dict] = []
        for v in self.validator.check_text(text_tp):
            out.append(
                {
                    "rule": v.rule,
                    "severity": v.severity,
                    "message": v.message,
                    "token_index": v.token_index,
                }
            )
        return out
