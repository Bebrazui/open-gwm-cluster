"""Загрузчики датасетов.

Архитектура сделана так, чтобы добавление нового датасета сводилось к
одной записи в реестре: любой jsonl/gz-jsonl с текстовыми полями
поддерживается классом JsonlCorpus, а OASST1 разбирается с учётом дерева
сообщений.

Пример добавления нового корпуса:

    DATASETS["my_corpus"] = lambda **kw: JsonlCorpus(
        path="data/my_corpus.jsonl",
        text_field="text",
        role_field="role",
        id_field="id",
        **kw,
    )
"""

from __future__ import annotations

import gzip
import io
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterator


@dataclass
class Message:
    """Сообщение корпуса в едином внутреннем формате."""

    message_id: str
    role: str
    text: str
    lang: str = "en"
    parent_id: str | None = None
    extra: dict = field(default_factory=dict)

    def to_json(self) -> dict:
        return {
            "message_id": self.message_id,
            "role": self.role,
            "lang": self.lang,
            "text": self.text,
            "parent_id": self.parent_id,
            **({"extra": self.extra} if self.extra else {}),
        }


def _open(path: str | Path) -> io.TextIOBase:
    path = Path(path)
    if path.suffix == ".gz":
        return gzip.open(path, "rt", encoding="utf-8")
    return open(path, "rt", encoding="utf-8")


class JsonlCorpus:
    """Универсальный корпус: jsonl/gz-jsonl с полями text/role/id/lang."""

    name = "jsonl"

    def __init__(
        self,
        path: str | Path,
        text_field: str = "text",
        role_field: str | None = "role",
        id_field: str | None = "id",
        lang_field: str | None = "lang",
        filter_lang: str | None = "en",
        skip_empty: bool = True,
        limit: int | None = None,
    ):
        self.path = Path(path)
        self.text_field = text_field
        self.role_field = role_field
        self.id_field = id_field
        self.lang_field = lang_field
        self.filter_lang = filter_lang
        self.skip_empty = skip_empty
        self.limit = limit

    def __iter__(self) -> Iterator[Message]:
        count = 0
        with _open(self.path) as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                data = json.loads(line)
                text = data.get(self.text_field)
                if not isinstance(text, str):
                    continue
                if self.skip_empty and not text.strip():
                    continue
                lang = ""
                if self.lang_field:
                    lang = str(data.get(self.lang_field, ""))
                if self.filter_lang and lang and not lang.startswith(self.filter_lang):
                    continue
                message_id = ""
                if self.id_field:
                    message_id = str(data.get(self.id_field, ""))
                if not message_id:
                    message_id = f"{self.name}-{count}"
                role = ""
                if self.role_field:
                    role = str(data.get(self.role_field, ""))
                yield Message(
                    message_id=message_id,
                    role=role,
                    text=text,
                    lang=lang or "en",
                    extra={k: v for k, v in data.items() if k not in {self.text_field}},
                )
                count += 1
                if self.limit and count >= self.limit:
                    return


class Oasst1Corpus(JsonlCorpus):
    """OpenAssistant OASST1 (снимок 2023-04-12)."""

    name = "oasst1"

    def __init__(
        self,
        path: str | Path = "data/2023-04-12_oasst_ready.messages.jsonl.gz",
        filter_lang: str | None = "en",
        include_deleted: bool = False,
        limit: int | None = None,
        **kwargs,
    ):
        super().__init__(
            path=path,
            text_field="text",
            role_field="role",
            id_field="message_id",
            lang_field="lang",
            filter_lang=filter_lang,
            limit=limit,
            **kwargs,
        )
        self.include_deleted = include_deleted

    def __iter__(self) -> Iterator[Message]:
        count = 0
        with _open(self.path) as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                data = json.loads(line)
                if data.get("deleted") and not self.include_deleted:
                    continue
                text = data.get("text") or ""
                if not text.strip():
                    continue
                lang = str(data.get("lang", ""))
                if self.filter_lang and not lang.startswith(self.filter_lang):
                    continue
                yield Message(
                    message_id=str(data.get("message_id", f"msg-{count}")),
                    role=str(data.get("role", "")),
                    text=text,
                    lang=lang or "en",
                    parent_id=data.get("parent_id"),
                    extra={
                        k: data[k]
                        for k in ("thread_id", "message_tree_id", "review_result", "synthetic")
                        if k in data
                    },
                )
                count += 1
                if self.limit and count >= self.limit:
                    return


#: Реестр корпусов: добавить новый датасет — одна строка.
DATASETS = {
    "oasst1": Oasst1Corpus,
}


def build_corpus(name: str, **kwargs) -> JsonlCorpus:
    """Создать корпус по имени из реестра."""
    if name not in DATASETS:
        raise KeyError(
            f"Неизвестный датасет «{name}». Доступны: {sorted(DATASETS)}. "
            "Добавьте его в DATASETS (tp_translate/corpora.py)."
        )
    return DATASETS[name](**kwargs)
