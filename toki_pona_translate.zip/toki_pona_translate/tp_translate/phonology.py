"""Фонология токи пона: алфавит, слоги, запреты, конвертация имён (nimi tawa).

Источники правил:
  * "Toki Pona: The Language of Good" (jan Sonja Lang), Lesson 1 и Lesson 9
    ("Proper Names") — PDF в refs/lipu_pu2.pdf;
  * sona.pona.la/wiki/Phonotactics (правила те же).
"""

from __future__ import annotations

import re

VOWELS = set("aeiou")
CONSONANTS = set("jklmnpstw")
ALPHABET = VOWELS | CONSONANTS  # 14 букв: a e i j k l m n o p s t u w

#: Слоги, которые запрещены фонематикой токи пона.
FORBIDDEN_SYLLABLES = {"ji", "wu", "wo", "ti"}

#: Запрещённые сочетания согласных (соседние носовые).
FORBIDDEN_CLUSTERS = ("nn", "nm")


def is_valid_letter(ch: str) -> bool:
    return ch in ALPHABET


def syllabify(word: str) -> list[str] | None:
    """Разбить слово на слоги по правилу (C)V(n).

    Возвращает None, если слово невозможно разбить по правилам токи пона.
    Первый слог может начинаться без согласной; дальше — обязательно CV(n).
    """
    if not word:
        return None
    syls: list[str] = []
    i = 0
    n = len(word)
    while i < n:
        start = i
        # онсет: согласная, только если сразу за ней гласная
        if (
            word[i] in CONSONANTS
            and i + 1 < n
            and word[i + 1] in VOWELS
        ):
            i += 1
        if i >= n or word[i] not in VOWELS:
            return None
        i += 1
        # кода: только носовая n
        if i < n and word[i] == "n":
            i += 1
        syls.append(word[start:i])
    return syls


def check_word(word: str) -> list[str]:
    """Проверить слово против фонематики. Возвращает список нарушений."""
    errors: list[str] = []
    if not word:
        return ["пустое слово"]
    # правильные имена в токи пона пишутся с заглавной буквы
    if word[1:] != word[1:].lower():
        errors.append("слово должно быть в нижнем регистре")
    bad = sorted({c for c in word if c not in ALPHABET})
    if bad:
        errors.append(f"недопустимые буквы: {''.join(bad)}")
        return errors  # дальше разбирать бессмысленно
    for cluster in FORBIDDEN_CLUSTERS:
        if cluster in word:
            errors.append(f"запрещённое сочетание согласных: '{cluster}'")
    syls = syllabify(word)
    if syls is None:
        errors.append("слово не разбивается на слоги (C)V(n)")
        return errors
    for s in syls:
        if s in FORBIDDEN_SYLLABLES:
            errors.append(f"запрещённый слог: '{s}'")
    return errors


def is_valid_word(word: str) -> bool:
    return not check_word(word)


# --------------------------------------------------------------------------
# Конвертация иностранных слов (nimi tawa) — Lesson 9 lipu pu
# --------------------------------------------------------------------------

#: Буквы английского алфавита, которых нет в токи пона, и их замены.
_LETTER_MAP = {
    "b": "p",
    "c": "k",
    "d": "t",
    "f": "p",
    "g": "k",
    "q": "k",
    "r": "l",
    "v": "w",
    "x": "ks",
    "y": "j",
    "z": "s",
    "h": "",  # h в токи пона нет; обычно глухой — выбрасываем
}


def _map_letters(word: str) -> str:
    out = []
    for ch in word.lower():
        if ch in ALPHABET:
            out.append(ch)
        elif ch in _LETTER_MAP:
            out.append(_LETTER_MAP[ch])
    return "".join(out)


def to_nimi_tawa(word: str) -> str:
    """Перевести иностранное слово в звучание токи пона (правила Lesson 9).

    1. Каждый слог: согласная + гласная + необязательное n.
    2. Первый слог может не начинаться с согласной.
    3. ti / tin → si / sin.
    4. w не бывает перед o/u.
    5. j не бывает перед i.

    Кластеры согласных схлопываются, соседние носовые не допускаются,
    лишние согласные отбрасываются, финальная n сохраняется.
    """
    w = _map_letters(word)
    if not w:
        return ""

    # шаг 3: ti/tin → si/sin
    w = re.sub(r"tin", "sin", w)
    w = re.sub(r"ti", "si", w)
    # шаг 4/5: w перед o/u и j перед i
    w = re.sub(r"w(?=[ou])", "", w)
    w = re.sub(r"j(?=i)", "s", w)
    # кластеры согласных схлопываются
    w = re.sub(r"([jklmnpstw])[jklmnpstw]{2,}", r"\1", w)

    # строим слоги заново: (C)V(n)
    out: list[str] = []
    pending = ""
    for ch in w:
        if ch in VOWELS:
            onset = ""
            if pending and pending[-1] in CONSONANTS:
                onset = pending[-1]
                pending = pending[:-1]
            out.append(onset + ch)
        else:
            pending += ch
    result = "".join(out)

    # хвостовые согласные: только n (как кода)
    if pending and result and pending.endswith("n"):
        result += "n"

    if not result:
        return ""
    if check_word(result):
        # запасной вариант: оставить только гласные
        result = "".join(ch for ch in result if ch in VOWELS)
    return result


def tokenize_toki(text: str) -> list[str]:
    """Разбить токи пона на слова (буквы токи пона + апостроф для n')."""
    return re.findall(r"[a-z]+(?:'[a-z]+)?", text.lower())
