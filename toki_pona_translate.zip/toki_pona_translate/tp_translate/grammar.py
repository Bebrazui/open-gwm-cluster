"""Валидатор грамматики токи пона.

Правила взяты из lipu pu ("Toki Pona: The Language of Good", jan Sonja Lang):
  * Lesson 1  — фонология: 14 букв, слог (C)V(n), запреты *ji, *wu, *wo, *ti;
  * Lesson 2  — существительные оканчиваются на n, прилагательные — нет;
  * Lesson 4/5 — порядок слов: подлежащее, li, сказуемое; e перед дополнением;
  * Lesson 6  — отрицание частицей ala после глагола;
  * Lesson 7  — вопросы: seme, anu seme, повтор глагола с ala;
  * Lesson 8  — предлоги: kepeken, lon, tan, tawa;
  * Lesson 11 — порядок модификаторов: голова noun-фразы идёт первой
                ("jan pona"), частица pi отделяет группу ("jan pi pona mute");
  * Lesson 12 — числа: ala(0), wan(1), tu(2), mute(3+), ale(∞);
  * Lesson 13 — предглаголы (wile, ken, kama, awen, sona, lukin);
  * Lesson 16 — частицы: a, o, la, en, e, li, pi.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from . import english as en
from .lexicon import Lexicon
from .phonology import check_word

#: Частицы и служебные слова токи пона.
PARTICLES = {"a", "e", "en", "kin", "la", "li", "o", "pi"}
PREPOSITIONS = {"kepeken", "lon", "tan", "tawa"}
PREVERBS = {"alasa", "awen", "kama", "ken", "lukin", "sona", "wile"}
PRONOUNS = {"mi", "sina", "ona"}
NUMBERS = {"ala", "wan", "tu", "mute", "ale", "luka", "pimeja"}

#: Слова, которые в токи пона работают и как существительное, и как глагол.
#: После «e» и предлогов они допустимы («e toki» = «слово»).
NOUN_LIKE_VERBS = {
    "toki", "pana", "musi", "moku", "lapi", "kama", "lukin", "sona",
    "tawa", "pali", "kalama", "awen", "open", "jo", "wawa", "seli", "mole",
    "wile", "ken", "nimi", "lipu", "kili", "ilo", "tomo", "telu", "telo",
}

#: Слова, которые читаются как предлог/предглагол, а не как прилагательное.
PREVERB_WORDS = PREVERBS | PREPOSITIONS

#: Допустимые слова с апострофом (li'u — «как»).
APOSTROPHE_WORDS = {"li'u"}


@dataclass
class Violation:
    rule: str
    severity: str  # error | warning | info
    message: str
    token_index: int | None = None

    def __str__(self) -> str:
        where = f" @{self.token_index}" if self.token_index is not None else ""
        return f"[{self.severity}] {self.rule}{where}: {self.message}"


class TokiPonaValidator:
    """Проверяет текст на токи пона и возвращает список нарушений."""

    def __init__(
        self,
        lexicon: Lexicon,
        known_loans: set[str] | None = None,
        tanru_order: str = "head_first",
    ):
        self.lexicon = lexicon
        self.known_loans = known_loans or set()
        self.tanru_order = tanru_order

    # -- публичный API ----------------------------------------------------
    def check_text(self, text: str) -> list[Violation]:
        """Проверить текст; код и ссылки не проверяются (они не переводятся)."""
        violations: list[Violation] = []
        for segment in en.split_segments(text):
            if not segment.translatable:
                continue
            for sentence in en.split_sentences(segment.text):
                if not sentence.strip():
                    continue
                violations.extend(self.check_sentence(sentence))
        return violations

    def check_sentence(self, sentence: str) -> list[Violation]:
        violations: list[Violation] = []
        tokens = re.findall(r"[a-z]+(?:'[a-z]+)?", sentence.lower())
        if not tokens:
            return violations

        for i, word in enumerate(tokens):
            violations.extend(self._check_word(word, i))

        violations.extend(self._check_structure(tokens))
        return violations

    # -- проверки ---------------------------------------------------------
    def _check_word(self, word: str, index: int) -> list[Violation]:
        out: list[Violation] = []
        if word in APOSTROPHE_WORDS:
            return out
        if word == "n":  # ономатопея из словаря ku, исключение из фонетики
            return out
        errors = check_word(word)
        for err in errors:
            out.append(Violation("phonology", "error", f"«{word}»: {err}", index))
        if not errors and not self._is_known(word):
            out.append(
                Violation(
                    "unknown_word",
                    "warning",
                    f"«{word}» не входит в официальный словарь (nimi pu/ku)",
                    index,
                )
            )
        return out

    def _is_known(self, word: str) -> bool:
        if word in APOSTROPHE_WORDS or word == "n":
            return True
        if self.lexicon.has_pos(word, "NOUN") or self.lexicon.has_pos(word, "ADJECTIVE"):
            return True
        if self.lexicon.has_pos(word, "VERB") or self.lexicon.has_pos(word, "PARTICLE"):
            return True
        if self.lexicon.has_pos(word, "PREPOSITION") or self.lexicon.has_pos(word, "PRE-VERB"):
            return True
        if self.lexicon.has_pos(word, "NUMBER") or word in self.lexicon.aliases:
            return True
        return word in self.known_loans

    def _check_structure(self, tokens: list[str]) -> list[Violation]:
        out: list[Violation] = []
        n = len(tokens)

        for i, word in enumerate(tokens):
            nxt = tokens[i + 1] if i + 1 < n else None

            # частица e должна стоять перед существительным
            if word == "e":
                if nxt is None:
                    out.append(Violation("particle_e", "error", "«e» без дополнения", i))
                elif not self._is_noun_start(nxt):
                    sev = "warning" if self._is_verbish(nxt) else "error"
                    out.append(
                        Violation(
                            "particle_e",
                            sev,
                            f"после «e» ожидается существительное, а не «{nxt}»",
                            i,
                        )
                    )

            # предлог должен вести к существительному
            if word in PREPOSITIONS:
                if nxt is None:
                    out.append(Violation("preposition", "error", f"«{word}» без объекта", i))
                elif not self._is_noun_start(nxt):
                    sev = "warning" if self._is_verbish(nxt) else "error"
                    out.append(
                        Violation(
                            "preposition",
                            sev,
                            f"после «{word}» ожидается существительное, а не «{nxt}»",
                            i,
                        )
                    )

            # li должен разделять подлежащее и сказуемое
            if word == "li":
                if i == 0:
                    out.append(Violation("particle_li", "error", "«li» в начале фразы", i))
                else:
                    prev = tokens[i - 1]
                    # «sina en mi li ...» — корректно; «... pi ... li ...» — допустимо
                    if prev == "e":
                        out.append(
                            Violation("particle_li", "error", "«li» после «e»", i)
                        )
                    elif prev == "pi":
                        out.append(
                            Violation("particle_li", "warning", "«li» после «pi»", i)
                        )

            # ala ставится после отрицаемого глагола
            if word == "ala":
                prev = tokens[i - 1] if i > 0 else None
                if prev is None:
                    out.append(Violation("negation", "warning", "«ala» в начале фразы", i))
                elif not (
                    self.lexicon.has_pos(prev, "VERB")
                    or prev in PREVERBS
                    or prev in {"jo", "kama", "pana", "musi", "moku"}
                ):
                    out.append(
                        Violation(
                            "negation",
                            "warning",
                            f"«ala» обычно следует за глаголом, а не за «{prev}»",
                            i,
                        )
                    )

            # частица pi
            if word == "pi":
                if nxt is None or not self._is_noun_start(nxt):
                    out.append(
                        Violation("particle_pi", "warning", "после «pi» ожидается существительное", i)
                    )

            if word == "seme":
                out.append(Violation("question", "info", "вопросительное слово «seme»", i))

        out.extend(self._check_li_usage(tokens))
        out.extend(self._check_tanru_order(tokens))
        return out

    @staticmethod
    def _is_verbish(word: str) -> bool:
        return word in NOUN_LIKE_VERBS or word in PREVERBS

    def _is_noun_start(self, word: str) -> bool:
        if word in PRONOUNS or word in NUMBERS:
            return True
        if word in self.known_loans:
            return True
        if self.lexicon.is_noun(word):
            return True
        if self.lexicon.is_adjective(word):
            return True
        if word in NOUN_LIKE_VERBS:
            return True
        return False

    def _check_li_usage(self, tokens: list[str]) -> list[Violation]:
        """Если подлежащее — существительное, а сразу идёт глагол, нужна li."""
        out: list[Violation] = []
        for i, word in enumerate(tokens[:-1]):
            nxt = tokens[i + 1]
            if nxt in {"li", "e", "o", "la", "a", "kin", "pi", "en"}:
                continue
            if word in PRONOUNS or word in PARTICLES or word in PREPOSITIONS:
                continue
            # проверяем только настоящее существительное токи пона
            if not self.lexicon.is_noun(word):
                continue
            # если существительное входит в состав другой группы — это не подлежащее
            if i > 0 and tokens[i - 1] not in {"li", "e", "en"}:
                if self.lexicon.is_noun(tokens[i - 1]) or self.lexicon.is_adjective(tokens[i - 1]):
                    continue
            if nxt in PREVERBS or nxt in PREVERB_WORDS:
                continue
            if not (self.lexicon.has_pos(nxt, "VERB") or nxt in PREVERBS):
                continue
            if nxt in NOUN_LIKE_VERBS:
                # «lipu toki» — существительное + слово, которое бывает и глаголом
                continue
            out.append(
                Violation(
                    "word_order",
                    "error",
                    f"после подлежащего «{word}» ожидается «li» перед «{nxt}»",
                    i,
                )
            )
        return out

    def _check_tanru_order(self, tokens: list[str]) -> list[Violation]:
        """Порядок модификаторов: в lipu pu голова noun-фразы идёт первой."""
        out: list[Violation] = []
        if self.tanru_order != "head_first":
            return out
        for i in range(len(tokens) - 1):
            a, b = tokens[i], tokens[i + 1]
            if a in PARTICLES or b in PARTICLES:
                continue
            if a in PREVERB_WORDS:
                continue
            if not self.lexicon.is_adjective(a):
                continue
            # b должно быть «чистым» существительным
            if not self.lexicon.is_noun(b):
                continue
            if self.lexicon.is_adjective(b) or self.lexicon.has_pos(b, "NUMBER"):
                continue
            out.append(
                Violation(
                    "tanru_order",
                    "warning",
                    f"«{a} {b}»: в lipu pu существительное-голова идёт первым "
                    f"(«{b} {a}»)",
                    i,
                )
            )
        return out

    # -- проверка самого лексикона ---------------------------------------
    def check_lexicon(self) -> list[Violation]:
        """Словарь сам должен соответствовать правилам (n у существительных)."""
        out: list[Violation] = []
        for word in self.lexicon.words:
            if self.lexicon.is_noun(word) and not word.endswith("n"):
                out.append(
                    Violation("lexicon", "error", f"существительное «{word}» не оканчивается на n")
                )
            if self.lexicon.is_adjective(word) and word.endswith("n"):
                out.append(Violation("lexicon", "error", f"прилагательное «{word}» оканчивается на n"))
        return out
